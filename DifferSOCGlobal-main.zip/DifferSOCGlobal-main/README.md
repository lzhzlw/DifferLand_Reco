# DifferSOCGlobal
