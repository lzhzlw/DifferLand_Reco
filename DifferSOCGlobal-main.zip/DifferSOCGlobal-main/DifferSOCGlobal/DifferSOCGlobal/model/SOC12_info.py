# Basic information about the DifferSOCGlobal framework
from collections import namedtuple
import jax.numpy as jnp


# extrenal forcing and parameter numbers of each module
# internal forcings and parameters are excluded
# and those have been used before will not be double counted
# number of [time-variant forcing, time-invariant frocing, pools, parameters]
tpf_info = jnp.array([3, 2, 0, 2])  # temperatuer and precipitation factor module
lit_info = jnp.array([1, 0, 1, 2])  # litter module
common_info = tpf_info + lit_info # [4, 2, 1, 4]
op_info = jnp.array([0, 0, 1, 1])  # one-pool SOC module
cs_info = jnp.array([0, 0, 3, 5])  # Century simplified SOC module
mesc_info = jnp.array([4, 4, 9, 12])  # MES-C SOC module
mill_info = jnp.array([4, 4, 10, 13])  # Millennial2 SOC module


# parameters
param_name = namedtuple('param_name', ['Tmp_sensitivity', 'Prcp_sensitivity',  # 2, temperature and precipitation factor module
                                       'k_litter', 'f_litter2soc',  # 2, litter module
                                       'k_soc',  # 1, one-pool SOC module
                                       'f_soc21', 'f_soc32', 'k_soc1', 'k_soc2', 'k_soc3',  # 5, Century simplified SOC module
                                       'fmet', 'kab', 'fm', 'av', 'ak', 'fs', 'tau_r',  # 12, MES-C SOC module
                                       'tau_k', 'kdesorp_mesc', 'qmaxcoeff_mesc', 'kma_mesc', 'floss_mesc',
                                       'fpoc', 'pa', 'Khalf_p2l', 'kpa', 'kb',
                                       'pb', 'kdesorp_mill', 'qmaxcoeff_mill', 'kma_mill', 'floss_mill', 
                                       'Khalf_l2b', 'kbd', 'cue_ref']) # 13, Millennial2 SOC module
param_min = jnp.array([0.018, 0.01,
                       1.0e-5, 1.0e-4, 
                       1.0e-7,
                       1.0e-7, 1.0e-7, 0.0027, 5.5e-5, 2.7e-6,
                       1.0e-6, 0.0019, 0.005, 8.0e-7, 1.0, 0.005, 5.2e-5,
                       2.4e-5, 0.1, 0.43, 0.002, 1.5e-4,
                       0.1, 0.1, 1000.0, 0.002, 0.002, 
                       0.1, 0.1, 0.43, 0.002, 1.5e-4,
                       29, 0.00036, 0.1])
param_max = jnp.array([0.08, 1.0,
                       0.01, 1.0, 
                       0.001,
                       0.4, 0.1, 1.0, 0.0027, 1.4e-5,
                       0.85, 0.19, 0.25, 2.4e-4, 300.0, 0.25, 0.0052, 
                       0.0024, 10.0, 4.3, 0.2, 0.015,
                       0.9, 0.9, 10000.0, 0.2, 0.2, 
                       0.9, 10.0, 4.3, 0.2, 0.015,
                       2900, 0.036, 0.9])
param_unit = ['', '',
              'day$^{-1}$', '',
              'day$^{-1}$', 
              '', '', 'day$^{-1}$', 'day$^{-1}$', 'day$^{-1}$',
              '', 'day-1', '', '', '', '', 'hour-1',
              'hour${-1}$', 'mg C L$^{-1}$ day$^{-1}$', '', 'day$^{-1}$', 'day$^{-1}$',
              '', '', 'g C m$^{-2}$', 'day$^{-1}$', 'day$^{-1}$',
              '', 'mg C L$^{-1}$ day$^{-1}$', '', 'day$^{-1}$', 'day$^{-1}$',
              'gc m$^{-2}$', 'm$^2$ g C${-1}$ day$^{-1}$', '']
num_fields = len(param_name._fields)
param_info = param_name(*jnp.arange(num_fields))

# divide into different module
# common module params
st = 0
end = common_info[3]
common_param_min = param_min[st:end]
common_param_max = param_max[st:end]
common_param_unit = param_unit[st:end]
# one-pool SOC module params
st = end
end = st + op_info[3]
op_param_min = param_min[st:end]
op_param_max = param_max[st:end]
op_param_unit = param_unit[st:end]
# Century simplified SOC module params
st = end
end = st + cs_info[3]
cs_param_min = param_min[st:end]
cs_param_max = param_max[st:end]
cs_param_unit = param_unit[st:end]
# MES-C SOC module params
st = end
end = st + mesc_info[3]
mesc_param_min = param_min[st:end]
mesc_param_max = param_max[st:end]
mesc_param_unit = param_unit[st:end]
# Millennial2 SOC module params
st = end
end = st + mill_info[3]
mill_param_min = param_min[st:end]
mill_param_max = param_max[st:end]
mill_param_unit = param_unit[st:end]

# pools
pool_name = namedtuple('pool_name', ['Litter', # 1, litter module
                                     'SOC',  # 1, one-pool SOC module
                                     'SOC1', 'SOC2', 'SOC3',  # 3, Century simplified SOC module
                                     'LITm', 'LITS', 'MICr', 'MICk', 'LMWC_mesc', 'MAOC_mesc',  # 9, MES-C SOC module
                                     'AGGm', 'AGGs', 'AGGmaoc',
                                     'POC', 'LMWC_mill', 'MAOC_mill', 'MIC', 'AGG', # 10, Millennial2 SOC module
                                     'POC14', 'LMWC14', 'MAOC14', 'MIC14', 'AGG14'])
pool_min = jnp.array([1.0, 
                      1.0,
                      0.009, 0.058, 0.503,
                      2.5e-3, 2.5e-3, 2.0e-3, 2.0e-3, 0.074, 0.35,
                      0.076, 0.076, 0.076,
                      1.0, 1.0, 1.0, 1.0, 1.0,
                      0.1, 0.1, 0.1, 0.1, 0.1])
pool_max = jnp.array([2000, 
                      2.0e5,
                      1.14e4, 9.52e4, 1.86e5,
                      6000.0, 6000.0, 2200.0, 2200.0, 5.86e4, 1.38e5,
                      2.26e4, 2.26e4, 2.26e4,
                      5.6e4, 2600.0, 1.38e5, 4400.0, 2.26e4,
                      11.2e4, 5200.0, 2.76e5, 8800.0, 4.52e4]) # twice the max of the corresponding pool
pool_unit = ['g C m$^{-2}$',
             'g C m$^{-2}$',
             'g C m$^{-2}$', 'g C m$^{-2}$', 'g C m$^{-2}$',
             'g C m$^{-2}$', 'g C m$^{-2}$', 'g C m$^{-2}$', 'g C m$^{-2}$', 'g C m$^{-2}$', 'g C m$^{-2}$',
             'g C m$^{-2}$', 'g C m$^{-2}$', 'g C m$^{-2}$',
             'g C m$^{-2}$', 'g C m$^{-2}$', 'g C m$^{-2}$', 'g C m$^{-2}$', 'g C m$^{-2}$', 
             'g C m$^{-2}$', 'g C m$^{-2}$', 'g C m$^{-2}$', 'g C m$^{-2}$', 'g C m$^{-2}$']

num_fields = len(pool_name._fields)
pool_info = pool_name(*jnp.arange(num_fields))

# divide into different module
# common module pools
st = 0
end = common_info[2]
common_pool_min = pool_min[st:end]
common_pool_max = pool_max[st:end]
common_pool_unit = pool_unit[st:end]
# one-pool SOC module pools
st = end
end = st + op_info[2]
op_pool_min = pool_min[st:end]
op_pool_max = pool_max[st:end]
op_pool_unit = pool_unit[st:end]
# Century simplified SOC module pools
st = end
end = st + cs_info[2]
cs_pool_min = pool_min[st:end]
cs_pool_max = pool_max[st:end]
cs_pool_unit = pool_unit[st:end]
# MES-C SOC module pools
st = end
end = st + mesc_info[2]
mesc_pool_min = pool_min[st:end]
mesc_pool_max = pool_max[st:end]
mesc_pool_unit = pool_unit[st:end]
# Millennial2 SOC module pools
st = end
end = st + mill_info[2]
mill_pool_min = pool_min[st:end]
mill_pool_max = pool_max[st:end]
mill_pool_unit = pool_unit[st:end]

# time variant forcings
varf_name = namedtuple('varf_name', ['Ta_max', 'Ta_min', 'Prcp',  # 3, temperature and precipitation factor module
                                     'Influx2Litter', # 1, litter module
                                     'NPP', 'SM', 'Ts', 'SMP', # 4, MES-C module
                                     'f14C']) # 4, Millennial2 module, including SM, Ts, SMP
varf_unit = ['degC', 'degC', 'mm day$^{-1}$',
             'g C m$^{-2}$ day$^{-1}$',
             'g C m$^{-2}$ day$^{-1}$', 'm3 m-3', 'degC', 'kPa',
             '']

# time invariant forcings
invarf_name = namedtuple('invarf_name', ['ave_Ta_mean', 'ave_Prcp',  # 2, temperature and precipitation factor module
                                         'BD', 'pH', 'Clay', 'Silt']) # 4, MES-C or Millennial2 SOC module
invarf_unit = ['degC', 'mm day$^{-1}$',
               'kg m$^{-3}$', '', '', '']


# targets
target_name = namedtuple('target_name', ['Litter', 'SOC', 'SOC1', 'SOC2', 'SOC3',
                                         'fMAOC', 'Rh', 'Rh_litter', 'Rh_soil', 'f_Rh_litter', 
                                         'SOC_in', 'SOC1_in', 'SOC2_in', 'SOC3_in',
                                         'SOC_out', 'SOC1_out', 'SOC2_out', 'SOC3_out'])
target_unit = ['g C m$^{-2}$', 'g C m$^{-2}$', 'g C m$^{-2}$', 'g C m$^{-2}$', 'g C m$^{-2}$',
               '%', 'g C m$^{-2}$ day$^{-1}$', 'g C m$^{-2}$ day$^{-1}$', 'g C m$^{-2}$ day$^{-1}$', '%',
               'g C m$^{-2}$ day$^{-1}$', 'g C m$^{-2}$ day$^{-1}$', 'g C m$^{-2}$ day$^{-1}$', 'g C m$^{-2}$ day$^{-1}$',
               'g C m$^{-2}$ day$^{-1}$', 'g C m$^{-2}$ day$^{-1}$', 'g C m$^{-2}$ day$^{-1}$', 'g C m$^{-2}$ day$^{-1}$']
num_fields = len(target_name._fields)
target_info = target_name(*jnp.arange(num_fields))

# ancient C fraction
faC_soc = 0.151039
faC_maoc = 0.147693
faC_poc = 0.205108

