# Function for environment factor
import jax.numpy as jnp


def tmp_prcp_factor(tpf_forcings, tpf_params):
    '''
    Function to calculate temperature and precipitation limitation factor on litter and soil turnover rate, unitless
     
    :param tpf_forcings: (5, ), 3 + 2 = 5 (time variant + time invariant)
    :param tpf_params: (2, )

    :return tpf: temperature and precipitation factor, unitless
    
    '''

    # parameters need to be constrained
    tmp_sensitivity = tpf_params[0]  # temperature sensitivity of litter and soil turnover rate, unitless
    prcp_sensitivity = tpf_params[1]  # precipitation sensitivity of litter and soil turnover rate, unitless

    # forcings
    # time variant
    ta_max = tpf_forcings[0]  # daily maximum air temperature, degC
    ta_min = tpf_forcings[1]  # daily minimum air temperature, degC
    prcp = tpf_forcings[2]  # daily precipitation, mm day-1
    # time invariant
    mean_ta = tpf_forcings[3]  # multi-year averaged daily air temperature, degC
    mean_prcp = tpf_forcings[4]  # multi-year averaged daily precipitation, mm day-1

    # calculating temperature (tf) and precipitation (pf) factor, unitless
    tf = jnp.exp(tmp_sensitivity * (0.5 * (ta_max + ta_min) - mean_ta))  # unitless
    pf = (prcp / mean_prcp - 1) * prcp_sensitivity + 1  # unitless
    tpf = tf * pf


    return tpf
     
