# Function for litter model
import jax.numpy as jnp
from DifferSOCGlobal.model.update_carbon import update_cpool_flux


def litter_allocation(lit_pool, lit_forcings, lit_params, lit_pools_min, lit_pools_max):
    '''
    Function for litter carbon allocation
    
    :param lit_pool: current litter carbon pool, g C m-2 (1, )
    :param lit_forcings: (3, ), 2 + 1 = 3 (time variant + time invariant)
    :param lit_params: (2, )
    :param lit_pools_min: prior minimum pool, g C m-2 (1, )
    :param lit_pools_max: prior maximum pool, g C m-2 (1, )
    
    :return next_lit_pool: next litter carbon pool, g C m-2 (1, )
    :return rh_litter: litter heterotrophic respiration, g C m-2 day-1
    :return litter2soc: litter to SOC flux, g C m-2 day-1

    '''
    
    # parameters need to be constrained
    k_litter = lit_params[0]  # turnover rate of litter
    f_litter2soc = lit_params[1]  # fraction of efflux from litter to SOC, unitless
    
    # forcings
    # time variant
    influx2litter = lit_forcings[0]  # g C m-2 day-1
    tpf = lit_forcings[1]  # temperature and precipitation limitation factor, unitless
    # time invariant
    delta_t = lit_forcings[2]  # time step, day(s)

    # pools and prior range, g C m-2
    litter_pool = lit_pool[0]
    litter_min = lit_pools_min[0]
    litter_max = lit_pools_max[0]

    # calculation
    litter_efflux = litter_pool * (1 - (1 - tpf * k_litter) ** delta_t) / delta_t
    next_litter_pool, litter_efflux = update_cpool_flux(
        litter_pool, litter_min, litter_max, influx2litter, litter_efflux, delta_t
    )
    litter2soc = f_litter2soc * litter_efflux
    litter2soc = jnp.maximum(litter2soc, 1e-6)
    rh_litter = litter_efflux - litter2soc
    
    return next_litter_pool, rh_litter, litter2soc

