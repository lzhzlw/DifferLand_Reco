# Function for soil organic carbon module
import jax
import jax.numpy as jnp
from DifferSOCGlobal.model.update_carbon import update_cpool_flux


def one_pool(soc_pools, soc_forcings, soc_params, soc_pools_min, soc_pools_max):
    '''
    Function for one-pool soil organic carbon model

    :param soc_pools: current SOC pool, g C m-2 (1, )
    :param soc_forcings: (3, ), 2 + 1 = 3 (time variant + time invariant)
    :param soc_params: (1, )
    :param soc_pools_min: prior minimum pool, g C m-2 (1, )
    :param soc_pools_max: prior maximum pool, g C m-2 (1, )

    :return next_soc_pool: next SOC pool, g C m-2 (1, )
    :return rh_soil: soil heterotrophic respiration, g C m-2 day-1
    :return soc_in: total carbon influx to soil, g C m-2 day-1
    :return soc_out: total carbon efflux from soil, g C m-2 day-1

    '''

    # parameter need to be constrained
    k_soc = soc_params[0]  # turnover rate of SOC to respiration, day-1
    
    # forcings
    # time variant
    c_in = soc_forcings[0]  # total carbon from litter to soil, g C m-2 day-1
    tpf = soc_forcings[1]  # temperature and precipitation limitation factor, unitless
    # time invariant
    delta_t = soc_forcings[2]  # time step in days, day(s)

    # pool
    soc_pool = soc_pools[0]  # total soc, g C m-2
    soc_pool_min = soc_pools_min[0]  # minimum soc, g C m-2
    soc_pool_max = soc_pools_max[0]  # maximum soc, g C m-2

    # soil heterotrophic respiration, g C m-2 day-1
    rh_soil = soc_pool * (1 - (1 - tpf * k_soc) ** delta_t) / delta_t
    # next soc pool, g C m-2
    next_soc_pool, rh_soil = update_cpool_flux(
        soc_pool, soc_pool_min, soc_pool_max, c_in, rh_soil, delta_t
    )

    soc_in = c_in
    soc_out = rh_soil

    return next_soc_pool, rh_soil, soc_in, soc_out


def Century_simplified(soc_pools, soc_forcings, soc_params, soc_pools_min, soc_pools_max):
    '''
    Function for simplified Century soil organic carbon model without depth consideration

    :param soc_pools: current SOC pools, g C m-2 (3, )
    :param soc_forcings: (3, ), 2 + 1 = 3 (time variant + time invariant)
    :param soc_params: (5, )
    :param soc_pools_min: prior minimum pools, g C m-2 (3, )
    :param soc_pools_max: prior maximum pools, g C m-2 (3, )

    :return next_soc_pools: next SOC pools, g C m-2 (3, )
    :return rh_soil: soil heterotrophic respiration, g C m-2 day-1
    :soc_in: total carbon influx to soil, g C m-2 day-1
    :soc_out: total carbon efflux from soil, g C m-2 day-1
    :soc1_in: carbon influx to SOC1, g C m-2 day-1
    :soc1_out: carbon efflux from SOC1, g C m-2 day-1
    :soc2_in: carbon influx to SOC2, g C m-2 day-1
    :soc2_out: carbon efflux from SOC2, g C m-2 day-1
    :soc3_in: carbon influx to SOC3, g C m-2 day-1
    :soc3_out: carbon efflux from SOC3, g C m-2 day-1
    
    '''

    # constant parameters
    f_litter2soc1 = 1.0  # fraction of litter to SOC1, unitless
    f_litter2soc2 = 0.0  # fraction of litter to SOC2, unitless
    f_litter2soc3 = 0.0  # fraction of litter to SOC3, unitless
    f_soc31 = 0.0  # fraction of SOC1 to SOC3, unitless
    f_soc12 = 0.0  # fraction of SOC2 to SOC1, unitless
    f_soc13 = 0.0  # fraction of SOC3 to SOC1, unitless
    f_soc23 = 0.0  # fraction of SOC3 to SOC2, unitless

    # parameters need to be constrained
    f_soc21 = soc_params[0]  # fraction of SOC1 to SOC2, unitless
    f_soc32 = soc_params[1]  # fraction of SOC2 to SOC3, unitless
    k_soc1 = soc_params[2]  # turnover rate for SOC1, day-1
    k_soc2 = soc_params[3]  # turnover rate for SOC2, day-1
    k_soc3 = soc_params[4]  # turnover rate for SOC3, day-1

    # forcings
    # time variant
    c_in = soc_forcings[0]  # total carbon from litter to soil, g C m-2 day-1
    tpf = soc_forcings[1]  # temperature and precipitation limitation factor, unitless
    # time invariant
    delta_t = soc_forcings[2]  # time step in days, day(s)

    # calculate in matric approach, dx/dt = b*u + A*k*x
    # where x is soil carbon pool vector, u is litter input, b is allocation matrix
    # A is transfer coefficient matrix, k is turnover rate matrix
    # ==========================================================================================
    # define matrices
    # allocation matrix, unitless
    b_matrix = jnp.array([f_litter2soc1, f_litter2soc2, f_litter2soc3])
    # transfer matrix, unitless
    A_matrix = jnp.array([[-1, f_soc12, f_soc13],
                          [f_soc21, -1, f_soc23],
                          [f_soc31, f_soc32, -1]])
    # turnover rate matrix (diagonal matrix) with environment factor, day-1
    k_elements = jnp.array([k_soc1, k_soc2, k_soc3])
    k_elements = (1 - (1 - tpf * k_elements) ** delta_t) / delta_t
    k_matrix = jnp.diag(k_elements)
    # current pool matrix, g C m-2
    x_matrix = jnp.array(soc_pools)
    # matrix calculation
    # part 1 total output, g C m-2 day-1
    out_matrix = k_matrix @ x_matrix
    # part2, output to other soc pools, g C m-2 day-1
    transfer_in_coe_matrix = jnp.array([[0, f_soc12, f_soc13],
                                        [f_soc21, 0, f_soc23],
                                        [f_soc31, f_soc32, 0]])
    transfer_out_coe_elements = jnp.nansum(transfer_in_coe_matrix, axis=0)
    # convert to diagonal matrix
    transfer_out_coe_matrix = jnp.diag(transfer_out_coe_elements)
    transfer_out_matrix = transfer_out_coe_matrix @ out_matrix
    # part3, output to rh
    rh_matrix = out_matrix - transfer_out_matrix
    # part4, input from litter to soc pools, g C m-2 day-1
    in_matrix = c_in * b_matrix
    # part5, input from other soc pools, replace the diagonal elements to 0
    transfer_in_matrix = transfer_in_coe_matrix @ out_matrix
    # part6, net fluxes, g C m-2 day-1
    flux_matrix = in_matrix + A_matrix @ out_matrix

    # update SOC pools, g C m-2
    # ==========================================================================================
    next_soc_pools = x_matrix + flux_matrix * delta_t
    # adjustment, assuming the transfer between soil carbon pools unchanged, adjust rh
    min_matrix = jnp.array(soc_pools_min)
    max_matrix = jnp.array(soc_pools_max)
    next_soc_pools = jnp.clip(next_soc_pools, min_matrix, max_matrix)
    rh_matrix = in_matrix + transfer_in_matrix - transfer_out_matrix - (next_soc_pools - x_matrix) / delta_t

    # cal total soil heterotrophic respiration
    rh_soil = jnp.sum(rh_matrix, axis=0)  # soil heterotrophic respiration, g C m-2 day-1

    # calculate fluxes, g C m-2 day-1
    soc_in = c_in
    soc_out = rh_soil
    soc1_in = in_matrix[0] + transfer_in_matrix[0]
    soc1_out = rh_matrix[0] + transfer_out_matrix[0]
    soc2_in = in_matrix[1] + transfer_in_matrix[1]
    soc2_out = rh_matrix[1] + transfer_out_matrix[1]
    soc3_in = in_matrix[2] + transfer_in_matrix[2]
    soc3_out = rh_matrix[2] + transfer_out_matrix[2]

    return next_soc_pools, rh_soil, soc_in, soc_out, soc1_in, soc1_out, soc2_in, soc2_out, soc3_in, soc3_out


def Vmax_mesc(Vs, Ts, Vint, av, Vmod):
    '''
    Function to calculate Vmax (maximum reaction velocity) for MESC, g Cs (g MIC)-1 day-1

    :param Vs: Temperature sensitivity for Vmax, ln(g Cs (g MIC)-1 hour-1) degC-1
    :param Ts: Soil temperature, degC
    :param Vint: Intercept for Vmax, ln(g Cs (g MIC)-1 hour-1)
    :param av: Tuning coefficient for Vmax, unitless
    :param Vmod: Modifier for Vmax, unitless

    :return: Vmax, g Cs (g MIC)-1 day-1
    
    '''

    Vmax = jnp.exp(Vs * Ts + Vint) * av * Vmod * 24.0  # from hour-1 to day-1

    return Vmax


def Km_mesc(Ks, Ts, Kint, ak, Kmod):
    '''
    Function to calculate Km (half saturation constant) for MESC, g MIC m-3 soil

    :param Ks: Temperature sensitivity for Km, ln(mg MIC cm-3 soil) degC-1
    :param Ts: Soil temperature, degC
    :param Kint: Intercept for Km, ln(mg MIC cm-3 soil)
    :param ak: Tuning coefficient for Km, unitless
    :param Kmod: Modifier for Km, unitless

    :return: Km, g MIC m-3 soil

    '''

    Km = jnp.exp(Ks * Ts + Kint) * ak * Kmod * 1000.0  # from mg MIC cm-3 soil to g MIC m-3 soil

    return Km


def MM_mesc(Vmax, Km, substrate, soil_thick):
    '''
    Function to calculate reaction rate based on Michaelis-Menten kinetics for MESC, g Cs (g MIC)-1 day-1

    :param Vmax: Maximum reaction velocity, g Cs (g MIC)-1 day-1
    :param Km: Half saturation constant, g MIC m-3 soil
    :param substrate: Substrate concentration, g MIC m-2 soil
    :param soil_thick: Soil thickness for the considered soil layer, m

    :return: rate, g Cs (g MIC)-1 day-1

    '''
    
    rate = Vmax * substrate / (Km * soil_thick + substrate)

    return rate


def MGE_mesc(coe, Ts):
    '''
    Function to calculate microbial growth efficiency (MGE) for MESC, mg mg-1
    
    :param coe: Coefficient for MGE, mg mg-1
    :param Ts: Soil temperature, degC

    :return: MGE, mg mg-1

    '''

    # -0.015 degC-1 is the temperature sensitivity for MGE 
    Tscalar = jnp.exp(-0.015 * Ts)
    MGE = coe * Tscalar

    return MGE


def MES_C(soc_pools, soc_forcings, soc_params, soc_pools_min, soc_pools_max):
    '''
    Function for MES-C SOC model without depth consideration
    
    Here the variable names are same as the supplementary document of MES-C model for clarity
    The variable names in the original fortran code are also provided in the comments for reference

    :param soc_pools: current SOC pools, g C m-2 (9, )
    :param soc_forcings: (10, ), 5 + 5 = 10 (time variant + time invariant)
    :param soc_params: (12, )
    :param soc_pools_min: prior minimum pools, g C m-2 (9, )
    :param soc_pools_max: prior maximum pools, g C m-2 (9, )

    :return next_soc_pools: next SOC pools, g C m-2 (9, )
    :return rh_soil: soil heterotrophic respiration, g C m-2 day-1
    :soc_in: total carbon influx to soil, g C m-2 day-1
    :soc_out: total carbon efflux from soil, g C m-2 day-1
    :soc1_in: carbon influx to POC, g C m-2 day-1
    :soc1_out: carbon efflux from POC, g C m-2 day-1
    :soc2_in: carbon influx to MAOC, g C m-2 day-1
    :soc2_out: carbon efflux from MAOC, g C m-2 day-1
    :soc3_in: carbon influx to MIC, g C m-2 day-1
    :soc3_out: carbon efflux from MIC, g C m-2 day-1

    '''

    # constant parameters
    # (Wieder, 2015)
    Vslope = 0.063  # temperature sensitivity for Vmax (sv), ln(mg Cs (mg MIC)-1 hour-1) degC-1
    Vint = 5.47  # intercept for Vmax (bv), ln(mg Cs (mg MIC)-1 hour-1)
    Vmod_r1 = 10.0  # modifier for Vmax, LIT_m to MIC_r (xv1), unitless
    Vmod_r2 = 2.0  # modifier for Vmax, LIT_s to MIC_r (xv2), unitless
    Vmod_r3 = 10.0  # modifier for Vmax, LMWC to MIC_r (xv3), unitless
    Vmod_k1 = 3.0  # modifier for Vmax, LIT_m to MIC_k (xw1), unitless
    Vmod_k2 = 3.0  # modifier for Vmax, LIT_s to MIC_k (xw2), unitless
    Vmod_k3 = 2.0  # modifier for Vmax, LMWC to MIC_k (xw3), unitless
    Kslope1 = 0.017  # temperature sensitivity for Km, LIT_m to MIC_r/k (sk), ln(mg MIC cm-3 soil) degC-1
    Kslope2 = 0.027  # temperature sensitivity for Km, LIT_s to MIC_r/k (skx), ln(mg MIC cm-3 soil) degC-1
    Kslope3 = 0.017  # temperature sensitivity for Km, LMWC to MIC_r/k (sk), ln(mg MIC cm-3 soil) degC-1
    Kint = 3.19  # intercept for Km (bk), ln(mg MIC cm-3 soil)
    Kmod_r1 = 1 / 8.0  # modifier for Km, LIT_m to MIC_r (1/xk1), unitless
    Kmod_r2 = 1 / 2.0  # modifier for Km, LIT_s to MIC_r (1/xk2), unitless
    Kmod_r3 = 1 / 4.0  # modifier for Km, LMWC to MIC_r (1/xk3), unitless
    Kmod_k1 = 1 / 2.0  # modifier for Km, LIT_m to MIC_k (1/xj1), unitless
    Kmod_k2 = 1 / 4.0  # modifier for Km, LIT_s to MIC_k (1/xj2), unitless
    Kmod_k3 = 1 / 6.0  # modifier for Km, LMWC to MIC_k (1/xj3), unitless
    coe_mge_r1 = 0.55 # coefficient for microbial growth efficiency, LIT_m to MIC_r (epsilon1), mg mg-1
    coe_mge_r2 = 0.25  # coefficient for microbial growth efficiency, LIT_s to MIC_r (epsilon2)
    coe_mge_r3 = 0.55  # coefficient for microbial growth efficiency, LMWC to MIC_r (epsilon1), mg mg-1
    coe_mge_k1 = 0.75  # coefficient for microbial growth efficiency, LIT_m to MIC_k (epsilon3), mg mg-1
    coe_mge_k2 = 0.35  # coefficient for microbial growth efficiency, LIT_s to MIC_k (epsilon4)
    coe_mge_k3 = 0.75  # coefficient for microbial growth efficiency, LMWC to MIC_k (epsilon3), mg mg-1
    # (Rose, 2022)
    lamda = 2.1e-4  # dependence of rate on matric potential, kpa-1
    kamin = 0.2  # minimum relative rate in saturated soil, unitless
    phcoeff1 = 0.186  # coefficient for estimating th ebinding affinity for LMWC sorption, unitless
    phcoeff2 = 0.216  # coefficient for estimating th ebinding affinity for LMWC sorption, unitless

    # parameters need to be constrained
    fmet = soc_params[0]  # fraction of carbon input to metabolic litter
    kab = soc_params[1]  # breakdown rate for AGG,day-1
    fm = soc_params[2]  # fraction of LIT_m to AGG_m, unitless
    av = soc_params[3]  # tuning coefficient for Vmax, unitless
    ak = soc_params[4]  # tuning coefficient for Km, unitless
    fs = soc_params[5]  # fraction of LIT_s to AGG_s, unitless
    tau_r = soc_params[6]  # turnover rate for MIC_r, hour-1
    tau_k = soc_params[7]  # turnover rate for MIC_k, hour-1
    kdesorp = soc_params[8]  # desorption rate for MAOC to LMWC, mg C L-1 day-1 or g C m-3 day-1
    qmaxcoeff = soc_params[9]  # coefficient for qmax, unitless
    kma = soc_params[10]  # formation rate for MAOC to AGG_maoc, day-1
    floss = soc_params[11]  # leaching loss rate for LMWC, day-1

    # forcings
    # time variant
    c_in = soc_forcings[0]  # total carbon from litter to soil, g C m-2 day-1
    npp = soc_forcings[1] * 365.25  # NPP from g C m-2 day-1 to g C m-2 year-1
    soil_moist = soc_forcings[2]  # soil moisture, m3 m-3
    Ts = soc_forcings[3]  # soil temperature, degC
    matpot = soc_forcings[4]  # matric potential, kPa
    
    # time invariant
    bulkd = soc_forcings[5]  # soil bulk density, kg m-3
    pore = 1.0 - bulkd / 2650.0  # soil porosity, mm3 mm-3
    ph = soc_forcings[6]  # soil pH, unitless
    clay = soc_forcings[7]  # soil clay fraction, unitless, 0-1
    silt = soc_forcings[8]  # soil silt fraction, unitless, 0-1
    soil_thick = soc_forcings[9]  # soil thickness for the considered soil layer, m
    delta_t = soc_forcings[10]  # time step in days, day(s)
    

    # pools, g C m-2
    litm_pool = soc_pools[0]  # Metabolic litter pool, LIT_m (m)
    lits_pool = soc_pools[1]  # Structural litter pool, LIT_s (s)
    micr_pool = soc_pools[2]  # Microbial biomass pool, r-stratagy, MIC_r (r)
    mick_pool = soc_pools[3]  # Microbial biomass pool, k-stratagy, MIC_k (k)
    lmwc_pool = soc_pools[4]  # Light molecule weight carbon pool, LMWC (a)
    maoc_pool = soc_pools[5]  # Mineral associated SOC pool, MAOC (c)
    # 3 aggregated organic matter pools, AGG_m, AGG_s, AGG_maoc (p)
    aggm_pool = soc_pools[6]
    aggs_pool = soc_pools[7]
    aggmaoc_pool = soc_pools[8]

    litm_min = soc_pools_min[0]
    lits_min = soc_pools_min[1]
    micr_min = soc_pools_min[2]
    mick_min = soc_pools_min[3]
    lmwc_min = soc_pools_min[4]
    maoc_min = soc_pools_min[5]
    aggm_min = soc_pools_min[6]
    aggs_min = soc_pools_min[7]
    aggmaoc_min = soc_pools_min[8]

    litm_max = soc_pools_max[0]
    lits_max = soc_pools_max[1]
    micr_max = soc_pools_max[2]
    mick_max = soc_pools_max[3]
    lmwc_max = soc_pools_max[4]
    maoc_max = soc_pools_max[5]
    aggm_max = soc_pools_max[6]
    aggs_max = soc_pools_max[7]
    aggmaoc_max = soc_pools_max[8]

    # LIT_m
    # ===================================================================================
    # Litter to LIT_m, g C m-2 day-1
    # fmet is a linear function of litter nitrogen to lignin ratio in the original code
    # Here it is taken as a parameter need to be constrained
    c_in_met = c_in * fmet
    # AGG_m to LIT_m, g C m-2 day-1
    # Water limitation on AGG breakdown, unitless, 0-1 (Ghezzehei et al., 2019)
    xwater1 = jnp.sqrt(jnp.clip(soil_moist / pore, 1e-6, 1.0))
    # breakdown rate for AGG, day-1, calculated the averaged daily flux during a delta_t
    # when the turnover is linear to pool size, solution for x(t) = x0 * exp(-kt)
    # when timestep is small, use the linear approximation, exp(-kt) ~ 1-kt
    # when timestep is large, use the linear approximation, exp(-k)t ~ (1-k)exp(t)
    fluxp2m = aggm_pool* (1 - (1 - xwater1 * kab) ** delta_t) / delta_t  # g C m-2 day-1
    # LIT_m to AGG_m, g C m-2 day-1
    fluxm2p = c_in_met * fm
    # LIT_m to MIC_r, reverse Michaelis-Menten kinetics, including respiration, g C m-2 day-1
    vmax_r1 = Vmax_mesc(Vslope, Ts, Vint, av, Vmod_r1)  # maximum reaction velocity, g Cs (g MIC)-1 day-1
    km_r1 = Km_mesc(Kslope1, Ts, Kint, ak, Kmod_r1)  # half saturation constant, g MIC m-3 soil
    fm2r = MM_mesc(vmax_r1, km_r1, micr_pool, soil_thick)  # reaction rate based on Michaelis-Menten kinetics, g Cs (g MIC)-1 day-1
    # Water limitation on microbial uptake, unitless, 0-1 (Abramoff et al., 2022, eqn. 15)
    tempt = jnp.sqrt(jnp.clip(1.0 - soil_moist / pore, 1e-6, 1.0))
    xwater2 = jnp.exp(lamda * matpot) * (kamin + (1.0 - kamin) * tempt) * xwater1
    xwater2 = jnp.clip(xwater2, 1e-6, 1.0)
    xph2 = 1.0 / (1.0 + jnp.exp(-(ph - 4.798) / 0.4246))  # pH limitation on microbial uptake for r strategist, unitless
    fluxm2r = litm_pool * (1 - (1 - xwater2 * xph2 * fm2r) ** delta_t) / delta_t  # g C m-2 day-1 
    # LIT_m to MIC_k, reverse Michaelis-Menten kinetics, including respiration, g C m-2 day-1
    vmax_k1 = Vmax_mesc(Vslope, Ts, Vint, av, Vmod_k1)  # g Cs (g MIC)-1 day-1
    km_k1 = Km_mesc(Kslope1, Ts, Kint, ak, Kmod_k1)  # g MIC m-3 soil
    fm2k = MM_mesc(vmax_k1, km_k1, mick_pool, soil_thick)  # g Cs (g MIC)-1 day-1
    xph3 = 1.0 / (1.0 + jnp.exp(-(ph - 3.022) / 0.428))  # pH limitation on microbial uptake for k strategist, unitless
    fluxm2k = litm_pool * (1 - (1 - xwater2 * xph3 * fm2k) ** delta_t) / delta_t  # g C m-2 day-1

    # LIT_s
    # ===================================================================================
    # Litter to LIT_s， g C m-2 day-1
    c_in_str = c_in * (1.0 - fmet)
    # AGG_s to LIT_s, g C m-2 day-1
    fluxp2s = aggs_pool * (1 - (1 - xwater1 * kab) ** delta_t) / delta_t
    # LIT_s to AGG_s, g C m-2 day-1
    fluxs2p = c_in_str * fs
    # LIT_s to MIC_r, reverse Michaelis-Menten kinetics, including respiration, g C m-2 day-1
    vmax_r2 = Vmax_mesc(Vslope, Ts, Vint, av, Vmod_r2)  # g Cs (g MIC)-1 day-1
    km_r2 = Km_mesc(Kslope2, Ts, Kint, ak, Kmod_r2)  # g MIC m-3 soil
    fs2r = MM_mesc(vmax_r2, km_r2, micr_pool, soil_thick)  # g Cs (g MIC)-1 day-1
    fluxs2r = lits_pool * (1 - (1 - xwater2 * xph2 * fs2r) ** delta_t) / delta_t  # g C m-2 day-1
    # LIT_s to MIC_k, reverse Michaelis-Menten kinetics, including respiration, g C m-2 day-1
    vmax_k2 = Vmax_mesc(Vslope, Ts, Vint, av, Vmod_k2)  # g Cs (g MIC)-1 day-1
    km_k2 = Km_mesc(Kslope2, Ts, Kint, ak, Kmod_k2)  # g MIC m-3 soil
    fs2k = MM_mesc(vmax_k2, km_k2, mick_pool, soil_thick)  # g Cs (g MIC)-1 day-1
    fluxs2k = lits_pool * (1 - (1 - xwater2 * xph3 * fs2k) ** delta_t) / delta_t  # g C m-2 day-1

    # MIC_r
    # ===================================================================================
    # LIT_m to MIC_r, g C m-2 day-1
    mge_r1 = MGE_mesc(coe_mge_r1, Ts)  # microbial growth efficiency, mg mg-1
    fluxm2r_net = fluxm2r * mge_r1  # exclude respiration, g C m-2 day-1
    fluxm2r_res = fluxm2r * (1.0 - mge_r1)  # respiration, g C m-2 day-1
    # LIT_s to MIC_r, g C m-2 day-1
    mge_r2 = MGE_mesc(coe_mge_r2, Ts)  # microbial growth efficiency, mg mg-1
    fluxs2r_net = fluxs2r * mge_r2  # exclude respiration, g C m-2 day-1
    fluxs2r_res = fluxs2r * (1.0 - mge_r2)  # respiration, g C m-2 day-1
    # LMWC to MIC_r, forward Michaelis-Menten kinetics, g C m-2 day-1
    vmax_r3 = Vmax_mesc(Vslope, Ts, Vint, av, Vmod_r3)  # g Cs (g MIC)-1 day-1
    km_r3 = Km_mesc(Kslope3, Ts, Kint, ak, Kmod_r3)  # g MIC m-3 soil
    # adjust Km based on clay content, only for LMWC to MIC_r/k, unitless
    Pscalar = 1.0 / (2.0 * jnp.exp(-2 * jnp.sqrt(clay)))
    km_r3 = km_r3 * Pscalar  # g MIC m-3 soil
    fa2r = MM_mesc(vmax_r3, km_r3, lmwc_pool, soil_thick)  # g Cs (g MIC)-1 day-1
    fluxa2r = lmwc_pool * (1 - (1 - xwater2 * xph2 * fa2r) ** delta_t) / delta_t  # g C m-2 day-1
    mge_r3 = MGE_mesc(coe_mge_r3, Ts)  # microbial growth efficiency, mg mg-1
    fluxa2r_net = fluxa2r * mge_r3  # exclude respiration, g C m-2 day-1
    fluxa2r_res = fluxa2r * (1.0 - mge_r3)  # respiration, g C m-2 day-1
    # MIC_r to SOC, including LMWC and MAOC, g C m-2 day-1
    # modifier for microbial turnover (Wielder et al., 2015, 0.8-1.2) (tvref)
    # 100 g C m-2 yr-1, referecne value for npp
    tau_mod = jnp.clip(jnp.sqrt(npp/100), 0.6, 1.3)  # unitless
    tau_r = tau_r * tau_mod * jnp.exp(0.3 * fmet) * 24.0  #  from per hour to per day
    # calculate the averaged daily flux during a delta_t
    # as the turnovet is non-linear to pool size, solution for x(t) = x0 / (1 + x0 * k * t)
    fluxr2ac = micr_pool ** 2 * tau_r / (micr_pool * tau_r * delta_t + 1.0)  # g C m-2 day-1

    # MIC_k
    # ===================================================================================
    # LIT_m to MIC_k, g C m-2 day-1
    mge_k1 = MGE_mesc(coe_mge_k1, Ts)  # microbial growth efficiency, mg mg-1
    fluxm2k_net = fluxm2k * mge_k1  # exclude respiration, g C m-2 day-1
    fluxm2k_res = fluxm2k * (1.0 - mge_k1)  # respiration, g C m-2 day-1
    # LIT_s to MIC_k, g C m-2 day-1
    mge_k2 = MGE_mesc(coe_mge_k2, Ts)  # microbial growth efficiency, mg mg-1
    fluxs2k_net = fluxs2k * mge_k2  # exclude respiration, g C m-2 day-1
    fluxs2k_res = fluxs2k * (1.0 - mge_k2)  # respiration, g C m-2 day-1
    # LMWC to MIC_k, forward Michaelis-Menten kinetics, g C m-2 day-1
    vmax_k3 = Vmax_mesc(Vslope, Ts, Vint, av, Vmod_k3)  # g Cs (g MIC)-1 day-1
    km_k3 = Km_mesc(Kslope3, Ts, Kint, ak, Kmod_k3)  # g MIC m-3 soil
    km_k3 = km_k3 * Pscalar
    fa2k = MM_mesc(vmax_k3, km_k3, lmwc_pool, soil_thick)  # g Cs (g MIC)-1 day-1
    fluxa2k = lmwc_pool * (1 - (1 - xwater2 * xph3 * fa2k) ** delta_t) / delta_t  # g C m-2 day-1
    mge_k3 = MGE_mesc(coe_mge_k3, Ts)  # microbial growth efficiency, mg mg-1
    fluxa2k_net = fluxa2k * mge_k3  # exclude respiration, g C m-2 day-1
    fluxa2k_res = fluxa2k * (1.0 - mge_k3)  # respiration, g C m-2 day-1
    # MIC_k to SOC, including LMWC and MAOC, g C m-2 day-1
    tau_k = tau_k * tau_mod * jnp.exp(0.1 * fmet) * 24.0  # per day
    fluxk2ac = mick_pool ** 2 * tau_k / (mick_pool * tau_k * delta_t + 1.0)  # g C m-2 day-1

    # LMWC
    # ===================================================================================
    # MIC_r to LMWC, g C m-2 day-1
    fr2p = 0.3 * jnp.exp(1.3 * clay)  # fraction of MIC_r to AGG, temporary value, unitless
    fr2c = jnp.clip(fr2p + 0.1 * jnp.exp(-3.0 * fmet), 0.0, 1.0)  # fraction of MIC_r to MAOC, unitless
    fr2p = 0
    fr2a = jnp.clip(1.0 - fr2c, 1e-6, 1.0)  # fraction of MIC_r to LMWC, unitless
    fluxr2a = fluxr2ac * fr2a
    # MIC_k to LMWC, g C m-2 day-1
    fk2p = 0.2 * jnp.exp(0.8 * clay)  # fraction of MIC_k to AGG, temporary value, unitless
    fk2c = jnp.clip(fk2p + 0.3 * jnp.exp(-3.0 * fmet), 0.0, 1.0)  # fraction of MIC_k to MAOC, unitless
    fk2p = 0
    fk2a = jnp.clip(1.0 - fk2c, 1e-6, 1.0)  # fraction of MIC_k to LMWC, unitless
    fluxk2a = fluxk2ac * fk2a
    # MAOC to LMWC, g C m-2 day-1
    qmax =  qmaxcoeff * (clay + silt) * 100.0 * bulkd * soil_thick  # from g C kg-1 soil to g C m-2 soil, bulkd in kg m-3, soil_thick in m
    fluxc2a = maoc_pool * (1 - ( 1 - kdesorp * soil_thick / qmax) ** delta_t) / delta_t  # g C m-2 day-1
    # LMWC to MIC_r, already included in MIC_r section
    # LMWC to MIC_k, already included in MIC_k section
    # LMWC to MAOC, g C m-2 day-1
    xph1 = jnp.exp(-phcoeff1 * ph - phcoeff2)  # euivalent to equilibrium constant, L mg-1, (Abramoff et al., 2022, eqn. 10)
    # need to consider lmwc and maoc pool size simutaneously
    # solution for x(t) = (C - qmax) / (1 - A(1+B)^t)
    # C = maoc0 + lmwc0, A = (qmax - maoc0) / lmwc0, B = (qmax - C) * k / qmax0
    kadsorp = kdesorp * xph1 # adsorption rate, day-1
    tempt_k = xwater1 * kadsorp  # effective adsorption rate, day-1
    tempt_C = maoc_pool + lmwc_pool  # total carbon for maoc and lmwc, g C m-2
    tempt_A = (qmax - maoc_pool) / lmwc_pool  # unitless
    tempt_B = (qmax - tempt_C) * tempt_k / qmax  # day-1
    lmwc_pool_delta_t = (tempt_C - qmax) / (1 - tempt_A * (1 + tempt_B) ** delta_t)  # g C m-2
    fluxa2c = (lmwc_pool - lmwc_pool_delta_t) / delta_t  # g C m-2 day-1
    # Leaching loss of LMWC, g C m-2 day-1 (currently not used)
    fluxaloss = 0 #lmwc_pool * (1 - (1 - xwater1 * floss) ** delta_t) / delta_t  # g C m-2 day-1

    # MAOC
    # ===================================================================================
    # MIC_r to MAOC, g C m-2 day-1
    fluxr2c = fluxr2ac * fr2c
    # MIC_k to MAOC, g C m-2 day-1
    fluxk2c = fluxk2ac * fk2c
    # LMWC to MAOC, already included in LMWC section
    # AGG_maoc to MAOC, g C m-2 day-1
    fluxp2c = aggmaoc_pool * (1 - (1 - xwater1 * kab) ** delta_t) / delta_t
    # MAOC to LMWC, already included in LMWC section
    # MAOC to AGG_maoc, g C m-2 day-1
    fluxc2p = maoc_pool * (1 - (1 - xwater1 * kma) ** delta_t) / delta_t

    # AGG
    # ===================================================================================
    # LIT_m to AGG_m, already included in LIT_m section
    # AGG_m to LIT_m, already included in LIT_m section

    # LIT_s to AGG_s, already included in LIT_s section
    # AGG_s to LIT_s, already included in LIT_s section

    # MAOC to AGG_maoc, already included in MAOC section
    # AGG_maoc to MAOC, already included in MAOC section

    # Update all pools
    # Agg_m
    next_aggm_pool, fluxp2m = update_cpool_flux(aggm_pool, aggm_min, aggm_max, fluxm2p, fluxp2m, delta_t)
    # Agg_s
    next_aggs_pool, fluxp2s = update_cpool_flux(aggs_pool, aggs_min, aggs_max, fluxs2p, fluxp2s, delta_t)
    # Agg_maoc
    next_aggmaoc_pool, fluxp2c = update_cpool_flux(aggmaoc_pool, aggmaoc_min, aggmaoc_max, fluxc2p, fluxp2c, delta_t)
    # MAOC
    next_maoc_pool, fluxc2a = update_cpool_flux(maoc_pool, maoc_min, maoc_max, fluxp2c + fluxr2c + fluxk2c + fluxa2c, 
                                                fluxc2a, delta_t, fluxc2p)
    # LIT_m
    fluxm_res = fluxm2r_res + fluxm2k_res
    fluxm2r_res_frac = fluxm2r_res / (fluxm_res + 1e-6)
    fluxm2r_res_frac = jnp.clip(fluxm2r_res_frac, 1e-6, 1.0)
    next_litm_pool, fluxm_res = update_cpool_flux(litm_pool, litm_min, litm_max, c_in_met + fluxp2m, 
                                                  fluxm_res, delta_t, fluxm2p + fluxm2r_net + fluxm2k_net)
    fluxm2r_res = fluxm_res * fluxm2r_res_frac
    fluxm2k_res = fluxm_res * (1.0 - fluxm2r_res_frac)
    fluxm2r = fluxm2r_net + fluxm2r_res
    fluxm2k = fluxm2k_net + fluxm2k_res
    # LIT_s
    fluxs_res = fluxs2r_res + fluxs2k_res
    fluxs2r_res_frac = fluxs2r_res / (fluxs_res + 1e-6)
    fluxs2r_res_frac = jnp.clip(fluxs2r_res_frac, 1e-6, 1.0)
    next_lits_pool, fluxs_res = update_cpool_flux(lits_pool, lits_min, lits_max, c_in_str + fluxp2s, 
                                                  fluxs_res, delta_t, fluxs2p + fluxs2r_net + fluxs2k_net)
    fluxs2r_res = fluxs_res * fluxs2r_res_frac
    fluxs2k_res = fluxs_res * (1.0 - fluxs2r_res_frac)
    fluxs2r = fluxs2r_net + fluxs2r_res
    fluxs2k = fluxs2k_net + fluxs2k_res
    # MIC_r
    next_micr_pool, fluxr2a = update_cpool_flux(micr_pool, micr_min, micr_max, fluxm2r_net + fluxs2r_net + fluxa2r_net, 
                                                fluxr2a, delta_t, fluxr2c)
    # MIC_k
    next_mick_pool, fluxk2a = update_cpool_flux(mick_pool, mick_min, mick_max, fluxm2k_net + fluxs2k_net + fluxa2k_net, 
                                                fluxk2a, delta_t, fluxk2c)
    # LMWC
    fluxa_res = fluxa2r_res + fluxa2k_res
    fluxa2r_res_frac = fluxa2r_res / (fluxa_res + 1e-6)
    fluxa2r_res_frac = jnp.clip(fluxa2r_res_frac, 1e-6, 1.0)
    next_lmwc_pool, fluxa_res = update_cpool_flux(lmwc_pool, lmwc_min, lmwc_max, fluxr2a + fluxk2a + fluxc2a, 
                                                  fluxa_res, delta_t, fluxa2c + fluxa2r_net + fluxa2k_net + fluxaloss)
    fluxa2r_res = fluxa_res * fluxa2r_res_frac
    fluxa2k_res = fluxa_res * (1.0 - fluxa2r_res_frac)
    fluxa2r = fluxa2r_net + fluxa2r_res
    fluxa2k = fluxa2k_net + fluxa2k_res

    # total soc, maoc and poc
    next_soc_pools = jnp.array([next_litm_pool, next_lits_pool, next_micr_pool, next_mick_pool, next_lmwc_pool, 
                                next_maoc_pool, next_aggm_pool, next_aggs_pool, next_aggmaoc_pool])

    # Soil heterotrophic respiration, g C m-2 day-1
    rh_soil = fluxm_res + fluxs_res + fluxa_res

    # influxes and effluxes
    soc_in = c_in
    soc_out = rh_soil + fluxaloss
    soc1_in =  fluxm2r_net + fluxs2r_net + fluxa2r_net + fluxm2k_net + fluxs2k_net + fluxa2k_net
    soc1_out = fluxr2a + fluxr2c + fluxk2a + fluxk2c
    soc2_in = c_in + fluxr2a + fluxk2a + fluxc2a
    soc2_out = (fluxm2r_net + fluxm2k_net + fluxs2r_net + fluxs2k_net + fluxa2r_net + fluxa2k_net +
                rh_soil + fluxa2c + fluxaloss)
    soc3_in = fluxr2c + fluxk2c + fluxa2c
    soc3_out = fluxc2a

    # jax.debug.breakpoint()

    return next_soc_pools, rh_soil, soc_in, soc_out, soc1_in, soc1_out, soc2_in, soc2_out, soc3_in, soc3_out

    # # Soil heterotrophic respiration, g C m-2 day-1
    # rh_litter = fluxm_res + fluxs_res 
    # rh_soil = fluxa_res

    # # influxes and effluxes
    # litter_in = c_in + fluxp2m + fluxp2s
    # litter_out = fluxm2p + fluxm2r + fluxm2k + fluxs2p + fluxs2r + fluxs2k
    # soc_in = litter_out - rh_litter
    # soc_out = rh_soil + fluxaloss + fluxp2m + fluxp2s
    # soc1_in =  fluxm2r_net + fluxs2r_net + fluxa2r_net + fluxm2k_net + fluxs2k_net + fluxa2k_net
    # soc1_out = fluxr2a + fluxr2c + fluxk2a + fluxk2c
    # soc2_in = fluxm2p + fluxs2p + fluxr2a + fluxk2a + fluxc2a
    # soc2_out = fluxp2m + fluxp2s + fluxa2r + fluxa2k + fluxa2c + fluxaloss
    # soc3_in = fluxr2c + fluxk2c + fluxa2c
    # soc3_out = fluxc2a

    # # jax.debug.breakpoint()

    # return (next_soc_pools, rh_soil, soc_in, soc_out, soc1_in, soc1_out, soc2_in, soc2_out, 
    #         soc3_in, soc3_out, litter_in, litter_out, rh_litter)


def Vmax_millennial2(alpha, Ea, Rgas, Ts):
    '''
    Function to calculate Vmax (maximum reaction velocity) for Millennial2, day-1

    :param alpha: Pre-exponential constant, day-1
    :param Ea: Activation energy, J mol-1
    :param Rgas: Gas constant, J mol-1 K-1
    :param Ts: Soil temperature, degC

    :return: Vmax, day-1
    
    '''

    Vmax = alpha * jnp.exp(-Ea / (Rgas * (Ts + 273.15)))

    return Vmax


def MM_millennial2(Vmax, Khalf, substrate):
    '''
    Function to calculate reaction rate based on Michaelis-Menten kinetics for Millennial2, day-1

    :param Vmax: Maximum reaction velocity, day-1
    :param Khalf: Half saturation constant, g C m-2
    :param substrate: Substrate concentration, g C m-2

    :return: rate, day-1

    '''
    
    rate = Vmax * substrate / (Khalf + substrate)

    return rate


def Millennial2(soc_pools, soc_forcings, soc_params, soc_pools_min, soc_pools_max):
    '''
    Function for Millennial SOC model without depth consideration

    :param soc_pools: SOC pool, (10, ), g C m-2
    :param soc_forcings: SOC forcings, (11, ), g C m-2 day-1
    :param soc_params: SOC parameters need to be constrained, (13, )
    :param soc_pools_min: Minimum SOC pool values, (10, ), g C m-2
    :param soc_pools_max: Maximum SOC pool values, (10, ), g C m-2

    :return: next_soc_pools: next SOC pool, (10, ), g C m-2
    :return rh_soil: soil heterotrophic respiration, g C m-2 day-1
    :soc_in: total carbon influx to soil, g C m-2 day-1
    :soc_out: total carbon efflux from soil, g C m-2 day-1
    :soc1_in: carbon influx to POC, g C m-2 day-1
    :soc1_out: carbon efflux from POC, g C m-2 day-1
    :soc2_in: carbon influx to MAOC, g C m-2 day-1
    :soc2_out: carbon efflux from MAOC, g C m-2 day-1
    :soc3_in: carbon influx to MIC, g C m-2 day-1
    :soc3_out: carbon efflux from MIC, g C m-2 day-1

    '''

    # Constant parameters
    Rgas = 8.31446 # gas constant, J K-1 mol-1
    alpha_p2l = 1.8e12 # pre-exponential constant for poc to lmwc, day-1
    Ea_p2l = 63909.0 # activation energy for poc to lmwc, J mol-1
    alpha_l2b = 2.3e12 # pre-exponential constant for lmwc to mic, day-1
    Ea_l2b = 57865.0 # activation energy for lmwc to mic, J mol-1
    phcoeff1 = 0.186 # coefficient for estimating the adsorption rate for lmwc to maoc, unitless
    phcoeff2 = 0.216 # coefficient for estimating the adsorption rate for lmwc to maoc, unitless
    lamda = 2.1e-4 # dependence of rate on soil matric potential, kPa-1
    kamin = 0.2 # minimum relative rate in saturated soil, unitless
    cue_ts = 0.012 # CUE dependence on temperature, degC-1
    Ts_ref = 15.0 # reference temperature for temperature control on CUE, degC

    # Parameters need to be constrained
    fpoc = 0.66#soc_params[0] # proportion of C input allocated to poc, unitless
    pa = 0.33#soc_params[1]  # proportion of agg breakdown allocated to poc, unitless
    Khalf_p2l = 6443#soc_params[2] # half saturation constant for poc to lmwc, g C m-2
    kpa = 0.018#soc_params[3] # rate of agg formation from poc, day-1
    kb = 0.02#soc_params[4]  # breakdown rate of agg, day-1
    pb = 0.5#soc_params[5] # proportion of necromass to maoc, unitless 
    kdesorp = 1.0#soc_params[6]  # desorption rate for maoc to lmwc, mg C L-1 day-1, or g C m-3 day-1
    qmaxcoeff = 0.86#soc_params[7]  # coefficient for estimating the qmax, unitless
    kma = 0.0048#soc_params[8]  # aggregate rate for maoc to agg, day-1
    floss = 0.0015#soc_params[9] # leaching rate of lmwc, day-1
    Khalf_l2b = 774.6#soc_params[10] # half saturation constant for lmwc to mic, g C m-2
    kbd = 0.0045#soc_params[11] # microbial death rate, m2 gC-1 day-1
    cue_ref = 0.19#soc_params[12] # reference CUE, unitless
    

    # Forcings
    # Time variant
    c_in = soc_forcings[0]  # net primary production, g C m-2 day-1
    soil_moist = soc_forcings[1]  # soil moisture/volumetric water content, mm3 mm-3
    Ts = soc_forcings[2]  # soil temperature, degC
    matpot = soc_forcings[3]  # soil matric potential, kPa
    f14_in = soc_forcings[4]  # ratio of 14C:12C in the C input, unitless
    
    # Time invariant
    bulkd = soc_forcings[5]  # soil bulk density, kg m-3
    pore = 1.0 - bulkd / 2650.0  # soil porosity, mm3 mm-3
    ph = soc_forcings[6]  # soil pH, unitless
    clay = soc_forcings[7]   # clay content, g g-1
    silt = soc_forcings[8]  # silt content, g g-1
    soil_thick = soc_forcings[9]  # soil depth, m
    delta_t = soc_forcings[10]  # time step in days

    # Pool, g C m-2
    # 12C
    poc_pool = soc_pools[0]  # particulate organic C pool
    lmwc_pool = soc_pools[1]  # low molecular weight C pool
    maoc_pool = soc_pools[2]  # mineral associated organic C pool
    mic_pool = soc_pools[3]  # microbial biomass C pool
    agg_pool = soc_pools[4]  # aggregate C pool
    # Pool minimum
    poc_min = soc_pools_min[0]
    lmwc_min = soc_pools_min[1]
    maoc_min = soc_pools_min[2]
    mic_min = soc_pools_min[3]
    agg_min = soc_pools_min[4]
    # Pool maximum
    poc_max = soc_pools_max[0]
    lmwc_max = soc_pools_max[1]
    maoc_max = soc_pools_max[2]
    mic_max = soc_pools_max[3]
    agg_max = soc_pools_max[4]
    # 14C
    poc14_pool = soc_pools[5]
    lmwc14_pool = soc_pools[6]
    maoc14_pool = soc_pools[7]
    mic14_pool = soc_pools[8]
    agg14_pool = soc_pools[9]

    poc14_min = soc_pools_min[5]
    lmwc14_min = soc_pools_min[6]
    maoc14_min = soc_pools_min[7]
    mic14_min = soc_pools_min[8]
    agg14_min = soc_pools_min[9]

    poc14_max = soc_pools_max[5]
    lmwc14_max = soc_pools_max[6]
    maoc14_max = soc_pools_max[7]
    mic14_max = soc_pools_max[8]
    agg14_max = soc_pools_max[9]

    # C flux, g C m-2 day-1
    # POC (p)
    # ===================================================================================
    # Litter to POC
    c_in_poc = c_in * fpoc
    # AGG to POC
    xwater1 = jnp.sqrt(jnp.clip(soil_moist / pore, 1e-6, 1.0))
    fluxa = agg_pool * (1 - (1 - xwater1 * kb) ** delta_t) / delta_t # averaged to delta t
    fluxa2p = fluxa * pa
    # POC to AGG
    fluxp2a = poc_pool * (1 - (1 - xwater1 * kpa) ** delta_t) / delta_t
    # POC to LMWC
    Vmaxp2l = Vmax_millennial2(alpha_p2l, Ea_p2l, Rgas, Ts)
    kp2l = MM_millennial2(Vmaxp2l, Khalf_p2l, mic_pool)
    fluxp2l = poc_pool * (1 - (1 - xwater1 * kp2l) ** delta_t) / delta_t

    # LMWC (l)
    # ===================================================================================
    # Litter to LMWC
    c_in_lmwc = c_in * (1 - fpoc)
    # POC to LMWC, already considered in POC section
    # MIC to LMWC
    fluxb = mic_pool ** 2 * kbd / (mic_pool * kbd * delta_t + 1.0)
    fluxb2l = fluxb * (1 - pb)
    # MAOC to LMWC, desorption
    qmax = qmaxcoeff * (clay + silt) * 100 * bulkd * soil_thick # g C m-2
    fluxm2l = maoc_pool * (1 - (1 - kdesorp * soil_thick/qmax) ** delta_t) / delta_t
    # LMWC to MAOC
    xph1 = jnp.exp(-phcoeff1 * ph - phcoeff2) # L mg-1
    kadsorp = kdesorp * xph1 # adsorption rate, day-1
    tempt_K = xwater1 * kadsorp
    tempt_C = lmwc_pool + maoc_pool
    tempt_A = (qmax - maoc_pool) / lmwc_pool
    tempt_B = (qmax - tempt_C) * tempt_K / qmax
    lmwc_pool_t = (tempt_C - qmax) / (1 - tempt_A * (1 + tempt_B) ** delta_t)
    fluxl2m = (lmwc_pool - lmwc_pool_t) / delta_t
    # LMWC to MIC
    tempt = jnp.sqrt(jnp.clip(1.0 - soil_moist / pore, 1e-6, 1.0))
    xwater2 = jnp.exp(lamda * matpot) * (kamin + (1.0 - kamin) * tempt) * xwater1
    xwater2 = jnp.clip(xwater2, 1e-6, 1.0)
    Vmaxl2b = Vmax_millennial2(alpha_l2b, Ea_l2b, Rgas, Ts)
    kl2b = MM_millennial2(Vmaxl2b, Khalf_l2b, lmwc_pool)
    fluxl2b = lmwc_pool * (1 - (1 - xwater2 * kl2b) ** delta_t) / delta_t
    # LMWC loss, not used here
    fluxl2loss = 0 # lmwc_pool * (1 - (1 - scalar_wd * kl) ** delta_t) / delta_t

    # AGG (a)
    # ===================================================================================
    # POC to AGG, already considered in POC section
    # MAOC to AGG
    fluxm2a = maoc_pool * (1 - (1 - xwater1 * kma) ** delta_t) / delta_t
    # AGG to POC and MAOC, already considered in POC section

    # MAOC (m)
    # ===================================================================================
    # LWMC to MAOC, already considered in LMWC section
    # AGG to MAOC
    fluxa2m = fluxa * (1 - pa)
    # MIC to MAOC
    fluxb2m = fluxb * pb
    # MAOC to LMWC, already considered in LMWC section
    # MAOC to AGG, already considered in AGG section

    # MIC (b)
    # ===================================================================================
    # LWMC to MIC, already considered in LMWC section
    # MIC to MAOC, already considered in MAOC section
    # MIC to atmosphere (CO2)
    cue = cue_ref - cue_ts * (Ts - Ts_ref)
    rh_soil = fluxl2b * (1 - cue)

    # Update carbon pools
    # Update AGG pool
    next_agg_pool, fluxa = update_cpool_flux(agg_pool, agg_min, agg_max, fluxp2a+fluxm2a, fluxa, delta_t)
    fluxa2p = fluxa * pa
    fluxa2m = fluxa * (1 - pa)
    # Update POC pool
    next_poc_pool, fluxp2l = update_cpool_flux(poc_pool, poc_min, poc_max, c_in_poc+fluxa2p, fluxp2l, delta_t, fluxp2a)
    # Update MAOC pool
    next_maoc_pool, fluxm2l = update_cpool_flux(maoc_pool, maoc_min, maoc_max, fluxl2m+fluxb2m+fluxa2m, fluxm2l, delta_t, fluxm2a)
    # Update LMWC pool
    next_lmwc_pool, fluxl2b = update_cpool_flux(lmwc_pool, lmwc_min, lmwc_max, c_in_lmwc+fluxp2l+fluxb2l+fluxm2l, fluxl2b, delta_t, fluxl2m+fluxl2loss)
    # Update MIC pool
    next_mic_pool, rh_soil = update_cpool_flux(mic_pool, mic_min, mic_max, fluxl2b, rh_soil, delta_t, fluxb)

    # 14C
    # ===================================================================================
    decay14c = jnp.log(2.0) / 5730 / 365 # radioactive decay rate of 14C, day-1
    # AGG
    fluxp2a14 = fluxp2a * poc14_pool / poc_pool
    fluxm2a14 = fluxm2a * maoc14_pool / maoc_pool
    fluxa14 = fluxa * agg14_pool / agg_pool
    fluxa14_decay = agg14_pool * (1 - (1 - decay14c) ** delta_t) / delta_t
    next_agg14_pool, fluxa14 = update_cpool_flux(agg14_pool, agg14_min, agg14_max, fluxp2a14+fluxm2a14, fluxa14, delta_t, fluxa14_decay)

    # POC
    c_in_poc14 = f14_in * c_in_poc
    fluxa2p14 = fluxa14 * pa
    fluxp2l14 = fluxp2l * poc14_pool / poc_pool
    fluxp14_decay = poc14_pool * (1 - (1 - decay14c) ** delta_t) / delta_t
    next_poc14_pool, fluxp2l14 = update_cpool_flux(poc14_pool, poc14_min, poc14_max, c_in_poc14+fluxa2p14, fluxp2l14, delta_t, fluxp2a14+fluxp14_decay)

    # MAOC
    fluxl2m14 = fluxl2m * lmwc14_pool / lmwc_pool
    fluxb14 = fluxb * mic14_pool / mic_pool
    fluxb2m14 = fluxb14 * pb
    fluxa2m14 = fluxa14 * (1 - pa)
    fluxm2l14 = fluxm2l * maoc14_pool / maoc_pool
    fluxm14_decay = maoc14_pool * (1 - (1 - decay14c) ** delta_t) / delta_t
    next_maoc14_pool, fluxm2l14 = update_cpool_flux(maoc14_pool, maoc14_min, maoc14_max, fluxl2m14+fluxb2m14+fluxa2m14, fluxm2l14, delta_t, fluxm2a14+fluxm14_decay)

    # LMWC
    c_in_lmwc14 = f14_in * c_in_lmwc
    fluxb2l14 = fluxb14 * (1 - pb)
    fluxl2b14 = fluxl2b * lmwc14_pool / lmwc_pool
    fluxl2loss14 = 0 # fluxl2loss * lmwc14_pool / lmwc_pool
    fluxl14_decay = lmwc14_pool * (1 - (1 - decay14c) ** delta_t) / delta_t
    next_lmwc14_pool, fluxl2b14 = update_cpool_flux(lmwc14_pool, lmwc14_min, lmwc14_max, c_in_lmwc14+fluxp2l14+fluxb2l14+fluxm2l14, fluxl2b14, delta_t, fluxl2m14+fluxl2loss14+fluxl14_decay)
    # MIC
    rh_soil14 = rh_soil * mic14_pool / mic_pool
    fluxb14_decay = mic14_pool * (1 - (1 - decay14c) ** delta_t) / delta_t
    next_mic14_pool, rh_soil14 = update_cpool_flux(mic14_pool, mic14_min, mic14_max, fluxl2b14, rh_soil14, delta_t, fluxb14+fluxb14_decay)

    # total soc, maoc and poc
    # next_soc_pools = jnp.array([next_poc_pool, next_lmwc_pool, next_maoc_pool, next_mic_pool, next_agg_pool])
    next_soc_pools = jnp.array([next_poc_pool, next_lmwc_pool, next_maoc_pool, next_mic_pool, next_agg_pool,
                                next_poc14_pool, next_lmwc14_pool, next_maoc14_pool, next_mic14_pool, next_agg14_pool])
    # soc1_pool = lmwc_pool + mic_pool # low molecular weight carbon and live microbial biomass
    # soc2_pool = poc_pool  # poc
    # soc3_pool = maoc_pool + agg_pool  # maoc
    # soc_pool = soc1_pool + soc2_pool + soc3_pool  # total soc
    # soc1_pool14 = ((lmwc14_pool + mic14_pool) / soc1_pool - 1) * 1000 # delta14C of poc pool, per mil
    # soc2_pool14 = (poc14_pool / poc_pool - 1) * 1000  
    # soc3_pool14 = ((maoc14_pool + agg14_pool) / soc2_pool - 1) * 1000
    # soc_pool14 = ((soc1_pool14 + soc2_pool14 + soc3_pool14) / soc_pool - 1) * 1000

    # influxes and effluxes
    soc_in = c_in
    soc_out = rh_soil + fluxl2loss
    soc1_in =  c_in_lmwc + fluxp2l + fluxm2l
    soc1_out = fluxl2m + fluxl2loss + rh_soil + fluxb2m
    soc2_in = c_in_poc + fluxa2p
    soc2_out = fluxp2a + fluxp2l
    soc3_in =  fluxp2a + fluxl2m + fluxb2m
    soc3_out = fluxa2p + fluxm2l

    # jax.debug.breakpoint()

    return next_soc_pools, rh_soil, soc_in, soc_out, soc1_in, soc1_out, soc2_in, soc2_out, soc3_in, soc3_out

