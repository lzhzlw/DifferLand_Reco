# Function for the SOC model
import jax
import jax.numpy as jnp
from functools import partial
import sys
from DifferSOCGlobal.model.SOC_class import SOC
from DifferSOCGlobal.model.SOC12_info import (common_info, op_info, cs_info, mesc_info, mill_info,
                                              common_param_min, common_param_max, common_pool_min, common_pool_max,
                                              op_param_min, op_param_max, op_pool_min, op_pool_max,
                                              cs_param_min, cs_param_max, cs_pool_min, cs_pool_max,
                                              mesc_param_min, mesc_param_max, mesc_pool_min, mesc_pool_max,
                                              mill_param_min, mill_param_max, mill_pool_min, mill_pool_max)
from DifferSOCGlobal.model.environment_factor import tmp_prcp_factor
from DifferSOCGlobal.model.litter_model import litter_allocation
from DifferSOCGlobal.model.soc_model import one_pool, Century_simplified, MES_C, Millennial2
from DifferSOCGlobal.util.normalization import unnormalize


class SOC12(SOC):
    def __init__(self, soc_type='mesc', time_step=30, soil_depth=200):
        super().__init__()
        self.soc_type = soc_type  # type of SOC module
        self.time_step = time_step # time step in days
        self.soil_depth = soil_depth / 100  # soil depth in m
        # extrenal forcing and parameter numbers of each module, (4, )
        # number of [time-variant forcing, time-invariant frocing, pools, parameters]
        self.common_info = common_info.tolist()
        self.op_info = op_info.tolist()
        self.cs_info = cs_info.tolist()
        self.mesc_info = mesc_info.tolist()
        self.mill_info = mill_info.tolist()
        # prior range of pools and parameters, further combine these 
        if soc_type == 'onepool':
            self.soc_param_min = op_param_min
            self.soc_param_max = op_param_max
            self.soc_pool_min = op_pool_min
            self.soc_pool_max = op_pool_max
        elif soc_type == 'century':
            self.soc_param_min = cs_param_min
            self.soc_param_max = cs_param_max
            self.soc_pool_min = cs_pool_min
            self.soc_pool_max = cs_pool_max
        elif soc_type == 'mesc':
            self.soc_param_min = mesc_param_min
            self.soc_param_max = mesc_param_max
            self.soc_pool_min = mesc_pool_min
            self.soc_pool_max = mesc_pool_max
        elif soc_type == 'millennial2':
            self.soc_param_min = mill_param_min
            self.soc_param_max = mill_param_max
            self.soc_pool_min = mill_pool_min
            self.soc_pool_max = mill_pool_max
        else:
            sys.exit('Error: wrong type of SOC module')
        self.param_min = jnp.concatenate((common_param_min, self.soc_param_min))
        self.param_max = jnp.concatenate((common_param_max, self.soc_param_max))
        self.pool_min = jnp.concatenate((common_pool_min, self.soc_pool_min))
        # Adjust the SOC pool maximum (ref, 200 cm depth) according to the soil depth
        beta = 0.9786
        update_soc_pool_max = self.soc_pool_max * (1 - jnp.power(beta, self.soil_depth * 100))/(1 - jnp.power(beta, 200))
        self.pool_max = jnp.concatenate((common_pool_max, update_soc_pool_max))


    @partial(jax.jit, static_argnums=(0,))
    def step(self, pools, var_forcings, invar_forcings, params):
        '''
        Function for the SOC model at specific grid and time

        :param pools: (n_pool, )
        :param var_forcings: (n_var, )
        :param invar_forcings: (n_invar, )
        :param params: (n_param, )

        :return new_pools: (n_pool, )
        :return targets: (n_tar, )

        '''

        # litter module
        # ========================================================================================================
        # temperature and precipitation limitation factor on litter and soil turnover rate, unitless
        tpf_vf = var_forcings[0:3]  # 3, ta_max, ta_min, prcp
        tpv_ivf = invar_forcings[0:2]  #  2, mean_ta, mean_prcp
        tpf_forcings = jnp.concatenate((tpf_vf, tpv_ivf))
        tpf_params = params[0:2]  # 2, tmp_sensitivity, prcp_sensitivity
        tpf = tmp_prcp_factor(tpf_forcings, tpf_params)
        # litter module
        lit_pool = pools[0:1]  # 1, litter_pool
        lit_vf_base = var_forcings[3:4]  # 1, influx2litter
        lit_forcings = jnp.concatenate((lit_vf_base, jnp.array([tpf, self.time_step])))  # 3, influx2litter, tpf, time step
        lit_params = params[2:4]  # 2, k_litter, f_litter2soc
        lit_pools_min = self.pool_min[0:1]
        lit_pools_max = self.pool_max[0:1]
        next_litter_pool, rh_litter, litter2soc = litter_allocation(lit_pool, lit_forcings, lit_params, lit_pools_min, lit_pools_max)
        litter_pool = next_litter_pool
        next_litter_pool = jnp.array([next_litter_pool])

        st_vf = self.common_info[0]
        st_ivf = self.common_info[1]
        st_pool = self.common_info[2]
        st_param = self.common_info[3]
        
        # soc module
        # ========================================================================================================
        # one-pool SOC module
        if self.soc_type == 'onepool':
            soc_forcings = jnp.concatenate((jnp.array([litter2soc, tpf]), jnp.array([self.time_step])))  # 3, litter2soc, tpf, time step
            soc_pools = pools[st_pool:st_pool+self.op_info[2]]  # 1, soc_pool
            soc_params = params[st_param:st_param+self.op_info[3]]  # 1, k_soc
            soc_pools_min = self.pool_min[st_pool:st_pool+self.op_info[2]]
            soc_pools_max = self.pool_max[st_pool:st_pool+self.op_info[2]]
            # soc1-3 are zero here for placeholder
            next_soc_pools, rh_soil, soc_in, soc_out = one_pool(
                soc_pools, soc_forcings, soc_params, soc_pools_min, soc_pools_max
            )
            soc_pool = soc_pools[0]
            next_soc_pools = jnp.array([next_soc_pools])
            soc1_pool, soc2_pool, soc3_pool = 0.0, 0.0, 0.0  # placeholder
            soc1_in, soc1_out, soc2_in, soc2_out, soc3_in, soc3_out = 0.0, 0.0, 0.0, 0.0, 0.0, 0.0

        # simplified Century SOC module
        elif self.soc_type == 'century':
            soc_forcings = jnp.concatenate((jnp.array([litter2soc, tpf]), jnp.array([self.time_step])))  # 3, litter2soc, tpf, time step
            soc_pools = pools[st_pool:st_pool+self.cs_info[2]]  # 3, soc1_pool, soc2_pool, soc3_pool
            # 5, f_soc21, f_soc32, k_soc1, k_soc2, k_soc3
            soc_params = params[st_param:st_param+self.cs_info[3]]
            soc_pools_min = self.pool_min[st_pool:st_pool+self.cs_info[2]]
            soc_pools_max = self.pool_max[st_pool:st_pool+self.cs_info[2]]
            next_soc_pools, rh_soil, soc_in, soc_out, soc1_in, soc1_out, soc2_in, soc2_out, soc3_in, soc3_out = Century_simplified(
                soc_pools, soc_forcings, soc_params, soc_pools_min, soc_pools_max
            )
            soc1_pool = soc_pools[0]
            soc2_pool = soc_pools[1]
            soc3_pool = soc_pools[2]
            soc_pool = soc1_pool + soc2_pool + soc3_pool

        # MES-C soc module
        elif self.soc_type == 'mesc':
            rh_litter = 0.0
            # 4, NPP, Soil mositure, soil temperature, soil matric potential
            soc_vf = var_forcings[st_vf:st_vf+self.mesc_info[0]]
            # 4, bulk density, soil pH, soil clay, soil silt
            soc_ivf = invar_forcings[st_ivf:st_ivf+self.mesc_info[1]]
            # add influx2litter, soil depth, time step
            soc_forcings = jnp.concatenate((lit_vf_base, soc_vf, soc_ivf, jnp.array([self.soil_depth, self.time_step])))
            # 9, litm, lits, micr, mick, lmwc, maoc, aggm, aggs, aggmaoc
            soc_pools = pools[st_pool:st_pool+self.mesc_info[2]]
            # 11, fmet, xkab, xfm, xav, xak, xfs, xtau, xksorp, xqmaxcoeff, xkma, xfloss
            soc_params = params[st_param:st_param+self.mesc_info[3]]
            soc_pools_min = self.pool_min[st_pool:st_pool+self.mesc_info[2]]
            soc_pools_max = self.pool_max[st_pool:st_pool+self.mesc_info[2]]
            next_soc_pools, rh_soil, soc_in, soc_out, soc1_in, soc1_out, soc2_in, soc2_out, soc3_in, soc3_out = MES_C(
                soc_pools, soc_forcings, soc_params, soc_pools_min, soc_pools_max
            )

            soc1_pool = soc_pools[2] + soc_pools[3]
            soc2_pool = soc_pools[0] + soc_pools[1] + soc_pools[4] + soc_pools[6] + soc_pools[7]
            soc3_pool = soc_pools[5] + soc_pools[8]
            soc_pool = soc1_pool + soc2_pool + soc3_pool

        elif self.soc_type == 'millennial2':
            # 4, Soil mositure, soil temperature, soil matric potential, fc14
            soc_vf = var_forcings[st_vf:st_vf+self.mill_info[0]]
            # 4, bulk density, soil pH, soil clay, soil silt
            soc_ivf = invar_forcings[st_ivf:st_ivf+self.mill_info[1]]
            # add litter2soc, soil depth, time step
            soc_forcings = jnp.concatenate((jnp.array([litter2soc]), soc_vf, soc_ivf, jnp.array([self.soil_depth, self.time_step])))
            # 10, lmwc, agg, poc, moac, mic for 12C and 14C
            soc_pools = pools[st_pool:st_pool+self.mill_info[2]]
            # 4, kb, pa, kld, kma
            soc_params = params[st_param:st_param+self.mill_info[3]]
            soc_pools_min = self.pool_min[st_pool:st_pool+self.mill_info[2]]
            soc_pools_max = self.pool_max[st_pool:st_pool+self.mill_info[2]]
            next_soc_pools, rh_soil, soc_in, soc_out, soc1_in, soc1_out, soc2_in, soc2_out, soc3_in, soc3_out = Millennial2(
                soc_pools, soc_forcings, soc_params, soc_pools_min, soc_pools_max
            )

            soc1_pool = soc_pools[1] + soc_pools[3]
            soc2_pool = soc_pools[0]
            soc3_pool = soc_pools[2] + soc_pools[4]
            soc_pool = soc1_pool + soc2_pool + soc3_pool
            
        else:
            sys.exit('Error: wrong type of SOC module')

        rh = rh_litter + rh_soil
        f_rh_litter = rh_litter / rh * 100 # %
        fmaoc = soc3_pool / soc_pool * 100 # %

        # next pools
        next_pools = jnp.concatenate((next_litter_pool, next_soc_pools))
        
        # target pool/flux
        targets = jnp.array([litter_pool, soc_pool, soc1_pool, soc2_pool, soc3_pool,
                             fmaoc, rh, rh_litter, rh_soil, f_rh_litter,
                             soc_in, soc1_in, soc2_in, soc3_in, 
                             soc_out, soc1_out, soc2_out, soc3_out])
        targets = jnp.concatenate((targets, pools))
        
        # jax.debug.breakpoint()

        return next_pools, targets
    

    @partial(jax.jit, static_argnums=(0,))
    def unnormalize_params(self, norm_param):
        '''Convert model parameters from the real space to the physcial range'''

        return unnormalize(norm_param, parmin = self.param_min, parmax = self.param_max)


    @partial(jax.jit, static_argnums=(0,))
    def unnormalize_pools(self, norm_pool):
        '''Convert pool values from the real space to the physical value range'''

        return unnormalize(norm_pool, parmin = self.pool_min, parmax = self.pool_max)

 
    @partial(jax.jit, static_argnums=(0,))
    def step_tem_batch(self, pools, var_forcings, invar_forcings, params):
        '''
        Function for the SOC model batch for all time
        
        :param pools: (n_pool, )
        :param var_forcings: (n_time, n_var)
        :param invar_forcings: (n_invar, )
        :param params: (n_param, )

        :return targets: (n_time, n_tar)

        '''

        params = self.unnormalize_params(params)
        pools = self.unnormalize_pools(pools)
        next_pools, targets = jax.lax.scan(
            partial(self.step, invar_forcings=invar_forcings, params=params), pools, var_forcings
        )

        return targets.squeeze()


    @partial(jax.jit, static_argnums=(0,))
    def step_spa_batch(self, pools, var_forcings, invar_forcings, params):
        '''
        Function for the SOC model batch for all grids
        
        :param pools: (n_grid,n_pool)
        :param var_forcings: (n_grid, n_time, n_var)
        :param invar_forcings: (n_grid, n_invar)
        :param params: (n_grid, n_param)

        :return targets: (n_grid, n_time, n_tar)

        '''
        
        batched_step = jax.vmap(self.step_tem_batch, in_axes=([0, 0, 0, 0]))
        targets = batched_step(pools, var_forcings, invar_forcings, params)

        return targets
    

    @partial(jax.jit, static_argnums=(0,))
    def compute_tempo_loss(self, pools, var_forcings, invar_forcings, params, var_obs, invar_obs, grid_weights,
                           obs_mean, obs_std, var_obs_ind, invar_obs_ind, params_ind, pools_ind):
        '''
        Function to calculate the loss at specific grid

        :param pools: (n_pool, )
        :param var_forcings: (n_time, n_var)
        :param invar_forcings: (n_invar, )
        :param params: (n_param, )
        :param var_obs: (n_time, n_var)
        :param invar_obs: (n_invar, )
        :param grid_weights: (n_invar, )
        :param obs_mean: (n_var+n_invar, )
        :param obs_std: (n_var+n_invar, )
        :param var_obs_ind: (n_var, )
        :param invar_obs_ind: (n_invar, )
        :param params_ind: (n_param, )
        :param pools_ind: (n_pool, )

        :return var_loss: (n_var, )
        :return invar_loss: (n_invar, )

        '''

        # get shape
        if var_obs is None:
            n_var = 0
        elif var_obs.ndim == 1:
            n_var = 1
        else:
            n_var = var_obs.shape[1]
        if invar_obs is None:
            n_invar = 0
        elif len(invar_obs.shape) == 0:
            n_invar = 1
        else:
            n_invar = invar_obs.shape[0]
        n_total = n_var + n_invar
        # run model
        models = self.step_tem_batch(pools, var_forcings, invar_forcings, params)
        # standardization
        if n_var >= 1:
            var_obs = (var_obs - obs_mean[:n_var]) / obs_std[:n_var]
        if n_invar >= 1:
            invar_obs = (invar_obs - obs_mean[n_var:n_total]) / obs_std[n_var:n_total]

        var_mod = None if len(var_obs_ind) == 0 else models[:, var_obs_ind]
        if var_mod is not None:
            var_mod = (var_mod - obs_mean[:n_var]) / obs_std[:n_var]

        invar_mod_flux = None if len(invar_obs_ind) == 0 else jnp.mean(models[:, invar_obs_ind], axis=0)
        unnorm_params = self.unnormalize_params(params)
        unnorm_pools = self.unnormalize_pools(pools)
        invar_mod_params = None if len(params_ind) == 0 else unnorm_params[params_ind]
        invar_mod_pools = None if len(pools_ind) == 0 else unnorm_pools[pools_ind]
        stacked_result = []
        if invar_mod_flux is not None:
            stacked_result.append(invar_mod_flux)
        if invar_mod_params is not None:
            stacked_result.append(invar_mod_params)
        if invar_mod_pools is not None:
            stacked_result.append(invar_mod_pools)
        # Perform the hstack only if there are values to stack
        if stacked_result:
            invar_mod = jnp.hstack(stacked_result)
            invar_mod = (invar_mod - obs_mean[n_var:n_total]) / obs_std[n_var:n_total]
        else:
            invar_mod = None

        # cal mse
        var_loss = jnp.mean((var_mod - var_obs) ** 2, axis=0) * grid_weights[:n_var] if n_var >= 1 else None
        invar_loss = (invar_mod - invar_obs) ** 2 * grid_weights[n_var:] if n_invar >= 1 else None

        # jax.debug.breakpoint()

        return var_loss, invar_loss


    @partial(jax.jit, static_argnums=(0,))
    def compute_loss_batch(self, pools, var_forcings, invar_forcings, params, var_obs, invar_obs, grid_weights,
                           obs_mean, obs_std, var_obs_ind, invar_obs_ind, params_ind, pools_ind):
        '''
        Function to calculate the loss, batch for all grids

        :param pools: (n_grid, n_pool)
        :param var_forcings: (n_grid, n_time, n_var)
        :param invar_forcings: (n_grid, n_invar)
        :param params: (n_grid, n_param)
        :param var_obs: (n_grid, n_time, n_var)
        :param invar_obs: (n_grid, n_invar)
        :param grid_weights: (n_grid, n_invar)
        :param obs_mean: (n_var+n_invar, )
        :param obs_std: (n_var+n_invar, )
        :param var_obs_ind: (n_var, )
        :param invar_obs_ind: (n_invar, )
        :param params_ind: (n_param, )
        :param pools_ind: (n_pool, )

        :return loss_ls: (n_grid, n_var+n_invar)

        '''
        
        batched_loss = jax.vmap(self.compute_tempo_loss,
                                in_axes=([0, 0, 0, 0, 0, 0, 0, None, None, None, None, None, None]))
        # var_loss, invar_loss = batched_loss(pools[0:2, :], var_forcings[0:2, 4:6, :], invar_forcings[0:2, :], params[0:2, :], var_obs[0:2, 4:6, :], invar_obs[0:2, :],
        #                                     grid_weights[0:2, :], obs_mean, obs_std, var_obs_ind, invar_obs_ind, params_ind, pools_ind)
        var_loss, invar_loss = batched_loss(pools, var_forcings, invar_forcings, params, var_obs, invar_obs, grid_weights,
                                            obs_mean, obs_std, var_obs_ind, invar_obs_ind, params_ind, pools_ind)
        if var_obs is None:
            n_var = 0
        elif var_obs.ndim == 2:
            n_var = 1
        else:
            n_var = var_obs.shape[2]
        if invar_obs is None:
            n_invar = 0
        elif invar_obs.ndim == 1:
            n_invar = 1
        else:
            n_invar = invar_obs.shape[1]

        loss_ls = []
        if n_var >= 1:
            for vari in range(n_var):
                loss_ls.append(var_loss[:, vari])
        if n_invar >= 1:
            for vari in range(n_invar):
                loss_ls.append(invar_loss[:, vari])

        # jax.debug.breakpoint()

        return loss_ls

        