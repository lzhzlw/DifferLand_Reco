"""An abstract class representing the SOC model"""
class SOC:
    def __init__(self):
        pass

    def step():
        raise NotImplementedError

    def unnormalize_params():
        raise NotImplementedError
    
