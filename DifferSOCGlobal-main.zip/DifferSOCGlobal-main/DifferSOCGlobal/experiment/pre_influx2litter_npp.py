# Code for extracting the Influx2litter and NPP from assimilating results
import pickle
import pandas as pd
import os
import xarray as xr
import sys
sys.path.insert(1, '../')
from DifferSOCGlobal.util.load_data import restore_to_original_length


def main():
    ref_path = r'/data1/fyliu/j_DifferLand_ET_SOC/output_soc_maoc/soc3_ge2/exp_1/mesc_pml2_all_time_ts_30_bs_400_lr_0.0005_epo_1000_it_1_r_42_unc_0_p2g_0_i_1.pkl'
    # load data
    time = pd.date_range('2001-01-01', '2018-12-31', freq='MS')
    varnames = ['NPP_assim', 'Influx2Litter_assim']
    unit = 'g C m-2 year-1'
    with open(ref_path, 'rb') as fp:
        result_ls = pickle.load(fp)
        (results, invariant_obs, variant_obs, grid_weights, loss_ls, mask_ls, region, lon, lat, 
        init_pools, init_params, VARNAME_LS, VAR_IND_LS, param_bound_ls) = result_ls
        results = results[:, :, [17, 30]] # npp, influx2litter
    for i in range(2):
        data = results[:, :, i]
        data = restore_to_original_length(data, mask_ls[3])
        var_ds = data.reshape(len(lat), len(lon), len(time))
        var_ds = xr.DataArray(var_ds, coords=[lat, lon, time], dims=["lat", "lon", "time"])
        var_ds['lon'] = xr.where(var_ds['lon'] > 180, var_ds['lon'] - 360, var_ds['lon'])
        # reshape to [time, lat, lon]
        var_ds = var_ds.transpose('time', 'lat', 'lon')

        varname = varnames[i]
        var_ds.name = varname
        var_ds.attrs['unit'] = unit
        for year in range(2001, 2019):
            outpath = rf'/data1/fyliu/DifferLand_forcing/forcing_monthly_05deg/{varname}/{varname}_{year}_monthly_0.5deg.nc'
            os.makedirs(os.path.dirname(outpath), exist_ok=True)
            var_ds.sel(time=str(year)).to_netcdf(outpath)
            print(f'Saving {varname} for year {year} to {outpath}')

    return


if __name__ == '__main__':

    main()