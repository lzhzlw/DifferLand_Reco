# Code for visualizing the results of a specific simulation

import os
import pickle
import sys
sys.path.insert(1, '../')
from DifferSOCGlobal.util.visualization import visualization_global
from DifferSOCGlobal.util.calibration_global import get_soc_type


def main():

    soc_config = 3
    exp = 1
    soc_type = get_soc_type(soc_config)
    result_path = rf'../../../output/soc{soc_config}/exp_{exp}/{soc_type}_all_time_ts_30_bs_400_lr_0.0005_epo_400_it_1_r_42_unc_0_p2g_0_i_1.pkl'
    with open(result_path, 'rb') as fp:
        result_ls = pickle.load(fp)
    
    fig_dir_base = rf'../../../fig/soc{soc_config}/exp_{exp}'
    fig_dir = os.path.join(fig_dir_base, os.path.basename(result_path)[:-4])
    MASK = None
    METRIC = 'R2'

    (results, invariant_obs, variant_obs, grid_weights, loss_ls, mask_ls, region, lon, lat, 
        init_pools, init_params, VARNAME_LS, VAR_IND_LS, param_bound_ls) = result_ls
    train_mask, _, test_mask, valid_mask = mask_ls
    
    visualization_global(result_ls, fig_dir, mask=MASK, metric=METRIC)

    return


if __name__ == "__main__":

    main()

