# Function to run specific calibration
import re
import jax.numpy as jnp
import time
import logging
import sys
sys.path.insert(1, '../')
from DifferSOCGlobal.util.calibration_global import parse_args, calibration_global
from DifferSOCGlobal.model.SOC12_info import (param_info, pool_info, target_info,
                                              common_info, op_info, cs_info, mesc_info, mill_info)


# Basic settings
# This part gennerally does not need to change, use default values is ok
# If necessary, you can use command line arguments to change them
# ============================================================================================
# ============================================================================================
# Parameters for optimization
args = parse_args()
VERBOSE = not args.silent  # whether to print information, deault is True, i.e., silence = False
SOC_CONFIG = args.soc_config  # 1: one pool; 2: simplified Century; 3: MES-C (default); 4: Millennial2 (coding in progress)
UNTM = args.unseen_time  # 0: all time (default); 1: unseen time (only use half of the temporal data to train the model)
RUN_INDEX = args.run_index  # index for independent calibrations, default = 1
RANDOM_SEED = args.random_seed  # default = 42
BATCH_SIZE = args.batch_size  # batch size for each batch training, default = 400
LEARNING_RATE = args.learning_rate  # learning rate for gradient based optimization, default = 0.0005
ITERATIONS = args.iteration  # iterations for each batch training, default = 1
EPOCHS = args.epoch  # total epochs for gradient based optimization, default = 400
EXP = args.experiment  # experiment name, default = 1
POINT2GRID = args.point2grid  # whether to use point2grid observations for SOC, SOC1 (POC) and SOC2 (MAOC), default = False
UNCERTAINTY = args.uncertainty  # whether to consider uncertainty of observations, default = False

# Manual setting
# ============================================================================================
# ============================================================================================
# Change this part according to your needs
# Parameters for soil depth, spatial and temporal range
SOIL_DEPTH = 100  # soil depth in cm
REGION = {
        "lat_min": -60,
        "lat_max": 80,
        "lon_min": -180,
        "lon_max": 180
    }
# For test
# REGION = {
#     "lat_min": 40,
#     "lat_max": 50,
#     "lon_min": 45,
#     "lon_max": 55
# }
YEAR_RANGE = [2001, 2018]  # start year and end year (included)
TIME_STEP = 30  # running time step of the model, monthly here, need to be consistent with the time-variant forcings/observations

# Parameters for the Neural Network module
NUM_HIDDEN = 32  # numbers of neurons
NUM_LAYER = 3  # numbers of hidden layers

# Parameters for visualization
VISUALIZATION = True # whether to plot the results
MASK = 'test'  # Plot results with testing ('test'), training ('train') or all (None) samples
METRIC = 'R2'  # R2, r or nnse, calculate performance based on which metric


def get_output_dir(SOC_CONFIG, EXP):
    ''' Get output directory '''

    OUT_DIR = f"../../../output/soc{SOC_CONFIG}/exp_{EXP}"
    LOG_DIR = f"../../../log/soc{SOC_CONFIG}/exp_{EXP}"
    FIG_DIR = f"../../../fig/soc{SOC_CONFIG}/exp_{EXP}"

    return OUT_DIR, LOG_DIR, FIG_DIR


def get_data_path(SOIL_DEPTH):
    ''' Get data path '''

    PREDICTOR_PATH = rf"/data1/fyliu/DifferLand_forcing/predictor_stack_05deg/predictor_stack_0_{SOIL_DEPTH}cm_0.5deg.nc"  # predictor
    FORCING_DIR = r"/data1/fyliu/DifferLand_forcing/forcing_monthly_05deg/"  # forcing
    OBSERVATION_DIR = r"/data1/fyliu/DifferLand_forcing/observation_monthly_05deg/"  # observation
    WEIGHT_DIR = r"/data1/fyliu/DifferLand_forcing/weight_05deg/"  # weight
    
    return PREDICTOR_PATH, FORCING_DIR, OBSERVATION_DIR, WEIGHT_DIR


def get_obs_ls(SOIL_DEPTH):
    ''' Get observation name list 
    Two kind of observations can be used for assimilation
    One is the carbon pools or fluxes, which will be compared with the process-based model outputs, e.g., SOC, GPP, LAI
    The other is the process-based model parameters and initial pools, if having their observations,
    they can also be used for assimilation, e.g., LMA
    
    '''

    VAR_OBS_LS = []  # obs name with temporal information
    # obs name without temporal information
    INVAR_OBS_LS = ["Rh", f"SOC_0_{SOIL_DEPTH}cm", f"MAOC_0_{SOIL_DEPTH}cm_Zhao2025_SoilGrids", f"fMAOC_0_{SOIL_DEPTH}cm"]
    INIT_PARAMS_LS = []  # these obs name is process-based model parameters
    INIT_POOLS_LS = []  # these obs name is process-based model pools, gennerally it is empty
    

    return VAR_OBS_LS, INVAR_OBS_LS, INIT_PARAMS_LS, INIT_POOLS_LS


# Manual setting end here
# ============================================================================================
# ============================================================================================


def get_varname_ls(VAR_OBS_LS, INVAR_OBS_LS, INIT_PARAMS_LS, INIT_POOLS_LS):
    ''' Get variable name list to adjust the observation name list to align with the model outputs '''

    VAR_OBS_LS_COPY = [var.split('_')[0] for var in VAR_OBS_LS]
    INVAR_OBS_LS_COPY = [var.split('_')[0] for var in INVAR_OBS_LS]
    INIT_PARAMS_LS_COPY = [var.split('_')[0] for var in INIT_PARAMS_LS]
    if 'POC' in INVAR_OBS_LS_COPY:
        INVAR_OBS_LS_COPY[INVAR_OBS_LS_COPY.index('POC')] = 'SOC2'
    if 'MAOC' in INVAR_OBS_LS_COPY:
        INVAR_OBS_LS_COPY[INVAR_OBS_LS_COPY.index('MAOC')] = 'SOC3'
    VARNAME_LS = [VAR_OBS_LS_COPY, INVAR_OBS_LS_COPY, INIT_PARAMS_LS_COPY, INIT_POOLS_LS]

    return VARNAME_LS


def get_var_idx(VAR_OBS_LS_COPY, INVAR_OBS_LS_COPY, INIT_PARAMS_LS_COPY, INIT_POOLS_LS, SOC_CONFIG,
                target_info, param_info, pool_info, common_info, op_info, cs_info, mesc_info):
    ''' Get variable idx for comparison with the model's outputs or parameters '''

    VAR_OBS_IND = jnp.array([getattr(target_info, field) for field in VAR_OBS_LS_COPY])
    INVAR_OBS_IND = jnp.array([getattr(target_info, field) for field in INVAR_OBS_LS_COPY])
    PARAMS_IND = jnp.array([getattr(param_info, field) for field in INIT_PARAMS_LS_COPY])
    for idx, idx_value in enumerate(PARAMS_IND):
        if idx_value >= common_info[3]:
            # SOC module
            if SOC_CONFIG == 1:
                PARAMS_IND[idx] = PARAMS_IND[idx] - common_info[3]  # One-pool
            elif SOC_CONFIG == 2:
                PARAMS_IND[idx] = PARAMS_IND[idx] - common_info[3] - op_info[3]  # Simplified Century
            elif SOC_CONFIG == 3:
                PARAMS_IND[idx] = PARAMS_IND[idx] - common_info[3] - op_info[3] - cs_info[3]  # MES-C
            elif SOC_CONFIG == 4:
                PARAMS_IND[idx] = PARAMS_IND[idx] - common_info[3] - op_info[3] - cs_info[3] - mesc_info[3]  # Millennial2
    POOLS_IND = jnp.array([getattr(pool_info, field) for field in INIT_POOLS_LS])
    for idx, idx_value in enumerate(POOLS_IND):
        if idx_value >= common_info[2]:
            # SOC module
            if SOC_CONFIG == 1:
                PARAMS_IND[idx] = PARAMS_IND[idx] - common_info[2]  # One-pool
            elif SOC_CONFIG == 2:
                PARAMS_IND[idx] = PARAMS_IND[idx] - common_info[2] - op_info[2]  # Simplified Century
            elif SOC_CONFIG == 3:
                PARAMS_IND[idx] = PARAMS_IND[idx] - common_info[2] - op_info[2] - cs_info[2]  # MES-C
            elif SOC_CONFIG == 4:
                PARAMS_IND[idx] = PARAMS_IND[idx] - common_info[2] - op_info[2] - cs_info[2] - mesc_info[2]  # Millennial2

    return VAR_OBS_IND, INVAR_OBS_IND, PARAMS_IND, POOLS_IND


def get_forcings(SOC_CONFIG, SOIL_DEPTH):
    ''' Get forcings name list '''

    INVAR_FORCING_LS = ["ave_Ta_mean", "ave_Prcp"]
    if SOC_CONFIG in [3, 4]:
        INVAR_FORCING_LS = INVAR_FORCING_LS + ["BD", "pH", "Clay", "Silt"]
    VAR_FORCING_LS = ["Ta_max", "Ta_min", "Prcp", "Influx2Litter_assim"]
    if SOC_CONFIG == 3:
        VAR_FORCING_LS = VAR_FORCING_LS + ["NPP_assim", f"SM_0_{SOIL_DEPTH}cm", f"Ts_0_{SOIL_DEPTH}cm", f"SMP_0_{SOIL_DEPTH}cm"]
    if SOC_CONFIG == 4:
        VAR_FORCING_LS = VAR_FORCING_LS + [f"SM_0_{SOIL_DEPTH}cm", f"Ts_0_{SOIL_DEPTH}cm", f"SMP_0_{SOIL_DEPTH}cm", "f14C"]

    return INVAR_FORCING_LS, VAR_FORCING_LS


def main():
    t0 = time.time()

    # Get output dir
    OUT_DIR, LOG_DIR, FIG_DIR = get_output_dir(SOC_CONFIG, EXP)
    # Get data path
    PREDICTOR_PATH, FORCING_DIR, OBSERVATION_DIR, WEIGHT_DIR = get_data_path(SOIL_DEPTH)
    # Get observation name list
    VAR_OBS_LS, INVAR_OBS_LS, INIT_PARAMS_LS, INIT_POOLS_LS = get_obs_ls(SOIL_DEPTH)
    # Get variable name list
    VARNAME_LS = get_varname_ls(VAR_OBS_LS, INVAR_OBS_LS, INIT_PARAMS_LS, INIT_POOLS_LS)
    # Get variable index list
    VAR_OBS_IND, INVAR_OBS_IND, PARAMS_IND, POOLS_IND = get_var_idx(
        VARNAME_LS[0], VARNAME_LS[1], VARNAME_LS[2], INIT_POOLS_LS, SOC_CONFIG,
        target_info, param_info, pool_info, common_info, op_info, cs_info, mesc_info
    )
    # Get forcings name list
    INVAR_FORCING_LS, VAR_FORCING_LS = get_forcings(SOC_CONFIG, SOIL_DEPTH)
    # Get total observation name list
    TOTAL_VAR_OBS_LS = VAR_OBS_LS.copy()
    TOTAL_INVAR_OBS_LS = (INVAR_OBS_LS + INIT_PARAMS_LS + INIT_POOLS_LS).copy()
    if POINT2GRID:
        for var_name in TOTAL_INVAR_OBS_LS:
            if re.search(r'SOC_|POC_|MAOC_', var_name):
                key = var_name.split('_')[0]
                new_key = f'{key}_p2g'
                new_var_name = var_name.replace(key, new_key)
                TOTAL_INVAR_OBS_LS[TOTAL_INVAR_OBS_LS.index(var_name)] = new_var_name
    # Get weights
    var_ls = TOTAL_VAR_OBS_LS+TOTAL_INVAR_OBS_LS
    OBS_WEIGHTS = jnp.ones(len(var_ls))
    # Get total number of initial pools and parameters
    soc_info = op_info if SOC_CONFIG == 1 else cs_info if SOC_CONFIG == 2 else mesc_info if SOC_CONFIG == 3 else mill_info
    THETA_POOLS = common_info[2] + soc_info[2]  # output initial pools for DALEC2
    THETA_OTHERS = common_info[3] + soc_info[3]  # output other params for DALEC2

    calibration_global(VERBOSE, SOC_CONFIG, UNTM, RUN_INDEX, RANDOM_SEED,  # params for optimization
                       OBS_WEIGHTS, BATCH_SIZE, LEARNING_RATE, ITERATIONS, EPOCHS, 
                       POINT2GRID, UNCERTAINTY,
                       VISUALIZATION, MASK, METRIC,  # params for visualization
                       LOG_DIR, OUT_DIR, FIG_DIR,   # params for output dir
                       PREDICTOR_PATH, FORCING_DIR, INVAR_FORCING_LS, VAR_FORCING_LS,  # params for load data
                       OBSERVATION_DIR, TOTAL_INVAR_OBS_LS, TOTAL_VAR_OBS_LS, WEIGHT_DIR,
                       TIME_STEP, REGION, YEAR_RANGE, SOIL_DEPTH,
                       NUM_HIDDEN, NUM_LAYER, THETA_POOLS, THETA_OTHERS,  # params for NN model
                       VARNAME_LS, VAR_OBS_IND, INVAR_OBS_IND, PARAMS_IND, POOLS_IND  # other params
                       )

    t1 = time.time()
    running_time = t1 - t0
    hours = int(running_time // 3600)
    minutes = int((running_time % 3600) // 60)
    seconds = int(running_time % 60)
    logging.info(f"Calibration COMPLETE! Running time: {hours} h, {minutes} min, {seconds} s")
    if VERBOSE:
        print(f"\nCalibration COMPLETE! Running time: {hours} h, {minutes} min, {seconds} s")

    return


if __name__ == "__main__":

    main()

